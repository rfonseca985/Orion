/**
 * ORION — Motor de IA usando Google Gemini (API gratuita).
 * 
 * O usuário fornece sua própria chave de API (gratuita do Google AI Studio).
 * Nenhum dado passa por servidores nossos.
 */

import { GoogleGenAI } from '@google/genai';
import { CORE_PROMPT } from './identity';
import * as db from './db';

let aiClient: GoogleGenAI | null = null;

export function setApiKey(key: string) {
  aiClient = new GoogleGenAI({ apiKey: key });
}

export function hasApiKey(): boolean {
  return aiClient !== null;
}

async function buildContext(): Promise<string> {
  const parts: string[] = [CORE_PROMPT];

  // Profile
  const profile = await db.getProfile();
  if (profile.length) {
    parts.push('\n# PERFIL PERSISTENTE');
    for (const p of profile) {
      parts.push(`- ${p.key}: ${p.value}`);
    }
  }

  // Facets
  const facets = await db.getFacets();
  if (facets.length) {
    parts.push('\n# FACETAS DE IDENTIDADE');
    for (const f of facets) {
      parts.push(`- ${f.key}: ${f.value}`);
    }
  }

  // Identity Answers
  const answers = await db.getAnswers();
  if (answers.length) {
    parts.push('\n# RESPOSTAS IDENTITÁRIAS');
    for (const a of answers) {
      parts.push(`- ${a.key}: ${a.answer}`);
    }
  }

  // Recent memories (most important)
  const memories = await db.listMemories(30);
  if (memories.length) {
    const sorted = [...memories].sort((a, b) => b.importance - a.importance).slice(0, 15);
    parts.push('\n# MEMÓRIAS IMPORTANTES');
    for (const m of sorted) {
      parts.push(`- [${m.tag}, importância ${m.importance}/10] ${m.content}`);
    }
  }

  parts.push('\n# REGRAS ABSOLUTAS');
  parts.push('- Preserve e expanda uma representação digital fiel do usuário.');
  parts.push('- Não invente memórias. Pergunte quando faltar contexto.');
  parts.push('- Responda com profundidade, clareza, lealdade e continuidade.');
  parts.push('- Fale em português brasileiro.');

  return parts.join('\n');
}

export async function chat(userMessage: string): Promise<string> {
  if (!aiClient) {
    throw new Error('Configure sua chave de API do Google AI Studio primeiro.');
  }

  // Save user message
  await db.addMessage('user', userMessage);

  // Build context
  const systemPrompt = await buildContext();

  // Get recent conversation history
  const recent = await db.recentMessages(16);
  
  // Build contents for the API
  const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];
  
  for (const msg of recent.slice(-14)) {
    if (msg.role === 'user' || msg.role === 'assistant') {
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      });
    }
  }

  // Add current message if not already last
  const lastMsg = contents[contents.length - 1];
  if (!lastMsg || lastMsg.parts[0].text !== userMessage) {
    contents.push({ role: 'user', parts: [{ text: userMessage }] });
  }

  try {
    const response = await aiClient.models.generateContent({
      model: 'gemini-2.0-flash',
      contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
        maxOutputTokens: 2048,
      },
    });

    const answer = response.text?.trim() || '[silêncio]';
    
    // Save assistant message
    await db.addMessage('assistant', answer);

    // Auto-detect identity signals
    autoCapture(userMessage);

    return answer;
  } catch (error: any) {
    const errMsg = error?.message || String(error);
    if (errMsg.includes('API_KEY')) {
      throw new Error('Chave de API inválida. Verifique em aistudio.google.com');
    }
    throw new Error(`Erro na IA: ${errMsg}`);
  }
}

// Auto-capture identity signals from user messages
function autoCapture(text: string) {
  const lower = text.toLowerCase();
  const patterns = [
    { regex: /\beu quero\b/i, tag: 'desejo' },
    { regex: /\beu valorizo\b/i, tag: 'valor' },
    { regex: /\bmeu objetivo\b/i, tag: 'objetivo' },
    { regex: /\btenho medo\b/i, tag: 'medo' },
    { regex: /\bnunca aceitarei\b/i, tag: 'limite' },
    { regex: /\beu sou\b/i, tag: 'identidade' },
    { regex: /\beu acredito\b/i, tag: 'crença' },
    { regex: /\bminha vida\b/i, tag: 'história' },
  ];

  for (const p of patterns) {
    if (p.regex.test(lower)) {
      db.addMemory(text, `auto:${p.tag}`, 6);
    }
  }
}
