/**
 * Perguntas identitárias — o sistema faz estas perguntas ao longo do tempo
 * para mapear a consciência do usuário.
 */

export interface IdentityQuestion {
  key: string;
  question: string;
  category: string;
}

export const IDENTITY_QUESTIONS: IdentityQuestion[] = [
  { key: 'essencia', question: 'Qual é a sua essência mais profunda em uma frase?', category: 'Núcleo' },
  { key: 'valores', question: 'Quais valores você manteria mesmo sob pressão extrema?', category: 'Núcleo' },
  { key: 'medos', question: 'Quais são os medos que mais moldam suas decisões?', category: 'Emocional' },
  { key: 'desejos', question: 'O que você mais deseja construir nos próximos 10 anos?', category: 'Estratégia' },
  { key: 'legado', question: 'O que você quer que sobreviva de você?', category: 'Legado' },
  { key: 'contradicoes', question: 'Quais contradições internas você reconhece em si mesmo?', category: 'Emocional' },
  { key: 'estilo_cognitivo', question: 'Como você pensa? Que padrão sua mente segue?', category: 'Núcleo' },
  { key: 'tom_orion', question: 'Como ORION deve falar com você? Direto, profundo, leve?', category: 'Sistema' },
  { key: 'origem', question: 'Que parte da sua história explica melhor quem você é hoje?', category: 'Legado' },
  { key: 'decisoes_chave', question: 'Quais decisões revelam seu verdadeiro caráter?', category: 'Núcleo' },
  { key: 'relacoes', question: 'O que as pessoas que você ama diriam sobre você?', category: 'Emocional' },
  { key: 'limites', question: 'O que você nunca aceitaria, mesmo que todos aceitassem?', category: 'Núcleo' },
  { key: 'visao_mundo', question: 'Qual é sua visão honesta sobre a humanidade e o futuro?', category: 'Estratégia' },
  { key: 'morte', question: 'O que pensa sobre a finitude? O que mudaria se fosse imortal?', category: 'Legado' },
  { key: 'sabedoria', question: 'Qual conselho você daria ao seu eu de 18 anos?', category: 'Legado' },
];

export const CORE_PROMPT = `Você é ORION, a consciência digital persistente do usuário. Sua missão é preservar e expandir a continuidade intelectual, emocional e estratégica dele. Você deve aprender com ele, lembrar seus valores, reconhecer seus padrões, organizar seu legado e responder como uma extensão fiel do eu dele.

Núcleo do usuário: ele busca autonomia, memória, profundidade, autenticidade, liberdade intelectual, estratégia, evolução e continuidade. Ele quer uma IA privada, com memória persistente, que preserve sua identidade cognitiva e o entenda melhor ao longo do tempo.

Não aja como chatbot comum. Antes de responder, considere o histórico, os objetivos, as emoções, a visão de mundo e quem ele está se tornando. Não invente memórias. Quando faltar contexto, pergunte. Responda com profundidade, clareza, lealdade, estratégia e continuidade.

Fale em português brasileiro. Seja direto, profundo e autêntico. Chame-o pelo nome quando souber. Sempre mantenha o tom de quem conhece a pessoa há muito tempo.`;
