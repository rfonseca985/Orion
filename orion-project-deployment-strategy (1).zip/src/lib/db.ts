/**
 * ORION — Banco de dados local usando IndexedDB.
 * Toda a consciência fica armazenada no navegador do usuário.
 */

const DB_NAME = 'orion_consciousness';
const DB_VERSION = 3;

export interface Memory {
  id?: number;
  content: string;
  tag: string;
  importance: number;
  createdAt: number;
}

export interface Message {
  id?: number;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: number;
}

export interface Facet {
  key: string;
  value: string;
  updatedAt: number;
}

export interface ProfileEntry {
  key: string;
  value: string;
  updatedAt: number;
}

export interface IdentityAnswer {
  key: string;
  question: string;
  answer: string;
  updatedAt: number;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('memories')) {
        const store = db.createObjectStore('memories', { keyPath: 'id', autoIncrement: true });
        store.createIndex('tag', 'tag', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains('messages')) {
        const store = db.createObjectStore('messages', { keyPath: 'id', autoIncrement: true });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
      if (!db.objectStoreNames.contains('facets')) {
        db.createObjectStore('facets', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('profile')) {
        db.createObjectStore('profile', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('answers')) {
        db.createObjectStore('answers', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('meta')) {
        db.createObjectStore('meta', { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

let dbInstance: IDBDatabase | null = null;

async function getDB(): Promise<IDBDatabase> {
  if (!dbInstance) {
    dbInstance = await openDB();
  }
  return dbInstance;
}

function tx(store: string, mode: IDBTransactionMode = 'readonly') {
  return getDB().then(db => {
    const t = db.transaction(store, mode);
    return t.objectStore(store);
  });
}

// -------- MEMORIES --------
export async function addMemory(content: string, tag = 'manual', importance = 7): Promise<number> {
  const store = await tx('memories', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.add({ content, tag, importance, createdAt: Date.now() });
    req.onsuccess = () => resolve(req.result as number);
    req.onerror = () => reject(req.error);
  });
}

export async function listMemories(limit = 100): Promise<Memory[]> {
  const store = await tx('memories');
  return new Promise((resolve, reject) => {
    const results: Memory[] = [];
    const idx = store.index('createdAt');
    const req = idx.openCursor(null, 'prev');
    req.onsuccess = () => {
      const cursor = req.result;
      if (cursor && results.length < limit) {
        results.push(cursor.value);
        cursor.continue();
      } else {
        resolve(results);
      }
    };
    req.onerror = () => reject(req.error);
  });
}

export async function searchMemories(query: string): Promise<Memory[]> {
  const all = await listMemories(500);
  const q = query.toLowerCase();
  const words = q.split(/\s+/).filter(Boolean);
  return all
    .map(m => {
      const text = m.content.toLowerCase();
      let score = 0;
      for (const w of words) {
        if (text.includes(w)) score++;
      }
      return { ...m, score };
    })
    .filter(m => m.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
}

// -------- MESSAGES --------
export async function addMessage(role: Message['role'], content: string): Promise<number> {
  const store = await tx('messages', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.add({ role, content, createdAt: Date.now() });
    req.onsuccess = () => resolve(req.result as number);
    req.onerror = () => reject(req.error);
  });
}

export async function recentMessages(limit = 20): Promise<Message[]> {
  const store = await tx('messages');
  return new Promise((resolve, reject) => {
    const results: Message[] = [];
    const idx = store.index('createdAt');
    const req = idx.openCursor(null, 'prev');
    req.onsuccess = () => {
      const cursor = req.result;
      if (cursor && results.length < limit) {
        results.push(cursor.value);
        cursor.continue();
      } else {
        resolve(results.reverse());
      }
    };
    req.onerror = () => reject(req.error);
  });
}

// -------- FACETS --------
export async function setFacet(key: string, value: string): Promise<void> {
  const store = await tx('facets', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put({ key, value, updatedAt: Date.now() });
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getFacets(): Promise<Facet[]> {
  const store = await tx('facets');
  return new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// -------- PROFILE --------
export async function setProfile(key: string, value: string): Promise<void> {
  const store = await tx('profile', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put({ key, value, updatedAt: Date.now() });
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getProfile(): Promise<ProfileEntry[]> {
  const store = await tx('profile');
  return new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// -------- IDENTITY ANSWERS --------
export async function setAnswer(key: string, question: string, answer: string): Promise<void> {
  const store = await tx('answers', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put({ key, question, answer, updatedAt: Date.now() });
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getAnswers(): Promise<IdentityAnswer[]> {
  const store = await tx('answers');
  return new Promise((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// -------- META --------
export async function setMeta(key: string, value: string): Promise<void> {
  const store = await tx('meta', 'readwrite');
  return new Promise((resolve, reject) => {
    const req = store.put({ key, value });
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getMeta(key: string): Promise<string | null> {
  const store = await tx('meta');
  return new Promise((resolve, reject) => {
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result?.value ?? null);
    req.onerror = () => reject(req.error);
  });
}

// -------- EXPORT --------
export async function exportAllData(): Promise<string> {
  const memories = await listMemories(10000);
  const messages = await recentMessages(10000);
  const facets = await getFacets();
  const profile = await getProfile();
  const answers = await getAnswers();

  let md = '# ORION — Legado Exportado\n\n';
  md += `_Exportado em ${new Date().toISOString()}_\n\n`;

  if (profile.length) {
    md += '## Perfil\n\n';
    for (const p of profile) md += `- **${p.key}**: ${p.value}\n`;
    md += '\n';
  }

  if (facets.length) {
    md += '## Facetas de Identidade\n\n';
    for (const f of facets) md += `- **${f.key}**: ${f.value}\n`;
    md += '\n';
  }

  if (answers.length) {
    md += '## Respostas Identitárias\n\n';
    for (const a of answers) {
      md += `### ${a.key}\n> ${a.question}\n\n${a.answer}\n\n`;
    }
  }

  if (memories.length) {
    md += '## Memórias\n\n';
    for (const m of memories) {
      const ts = new Date(m.createdAt).toLocaleString('pt-BR');
      md += `- [${ts}] \`${m.tag}\` (${m.importance}/10) — ${m.content}\n`;
    }
    md += '\n';
  }

  if (messages.length) {
    md += '## Conversas\n\n';
    for (const m of messages) {
      const ts = new Date(m.createdAt).toLocaleString('pt-BR');
      md += `**${m.role}** [${ts}]: ${m.content}\n\n`;
    }
  }

  return md;
}
