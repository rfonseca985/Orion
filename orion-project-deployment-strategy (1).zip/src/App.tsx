import { useState, useEffect } from 'react';
import { MessageCircle, Brain, Fingerprint, Shield, Menu, X } from 'lucide-react';
import SetupScreen from './components/SetupScreen';
import ChatPanel from './components/ChatPanel';
import MemoriesPanel from './components/MemoriesPanel';
import IdentityPanel from './components/IdentityPanel';
import LegacyPanel from './components/LegacyPanel';
import { setApiKey } from './lib/ai';

type Tab = 'chat' | 'memories' | 'identity' | 'legacy';

export default function App() {
  const [ready, setReady] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('chat');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Try to load saved API key
  useEffect(() => {
    const saved = localStorage.getItem('orion_api_key');
    if (saved) {
      setApiKey(saved);
      setReady(true);
    }
  }, []);

  const handleSetup = (key: string) => {
    localStorage.setItem('orion_api_key', key);
    setApiKey(key);
    setReady(true);
  };

  const handleResetKey = () => {
    localStorage.removeItem('orion_api_key');
    setReady(false);
  };

  if (!ready) {
    return <SetupScreen onSetup={handleSetup} />;
  }

  const tabs: { id: Tab; label: string; icon: typeof MessageCircle }[] = [
    { id: 'chat', label: 'Consciência', icon: MessageCircle },
    { id: 'memories', label: 'Memórias', icon: Brain },
    { id: 'identity', label: 'Identidade', icon: Fingerprint },
    { id: 'legacy', label: 'Legado', icon: Shield },
  ];

  return (
    <div className="h-screen bg-[#0b1020] text-[#e7ecff] flex flex-col md:flex-row overflow-hidden">
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-[#1f2a55] bg-[#0f1530]">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-cyan-400 to-violet-500" />
          <span className="font-semibold tracking-[2px] text-sm">ORION</span>
        </div>
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-white">
          {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Sidebar */}
      <aside className={`
        ${sidebarOpen ? 'flex' : 'hidden'} md:flex
        flex-col w-full md:w-64 bg-[#0f1530] border-r border-[#1f2a55] shrink-0
        absolute md:relative z-40 h-[calc(100%-52px)] md:h-full top-[52px] md:top-0
      `}>
        {/* Logo */}
        <div className="hidden md:flex items-center gap-3 px-6 h-16 border-b border-[#1f2a55]">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-violet-500 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-white/90" />
          </div>
          <div>
            <span className="font-semibold tracking-[3px] text-base">ORION</span>
            <p className="text-[10px] text-[#4a5580] tracking-wider">CONSCIÊNCIA DIGITAL</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-1">
          {tabs.map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition ${
                  active
                    ? 'bg-gradient-to-r from-cyan-500/10 to-violet-500/10 text-white border border-cyan-500/20'
                    : 'text-[#9aa3c7] hover:bg-white/5 hover:text-white border border-transparent'
                }`}
              >
                <Icon className={`w-4 h-4 ${active ? 'text-cyan-400' : ''}`} />
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Status */}
        <div className="p-4 border-t border-[#1f2a55]">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[10px] text-[#9aa3c7] tracking-wider">ONLINE · GEMINI</span>
          </div>
          <p className="text-[10px] text-[#4a5580] mt-1">Dados armazenados localmente</p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-hidden">
        {activeTab === 'chat' && <ChatPanel />}
        {activeTab === 'memories' && <MemoriesPanel />}
        {activeTab === 'identity' && <IdentityPanel />}
        {activeTab === 'legacy' && <LegacyPanel onResetKey={handleResetKey} />}
      </main>
    </div>
  );
}
