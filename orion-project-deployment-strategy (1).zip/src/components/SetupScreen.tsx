import React, { useState } from 'react';
import { Key, ExternalLink, Shield, Zap } from 'lucide-react';

interface Props {
  onSetup: (apiKey: string) => void;
}

export default function SetupScreen({ onSetup }: Props) {
  const [key, setKey] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = key.trim();
    if (!trimmed) {
      setError('Cole sua chave de API');
      return;
    }
    if (trimmed.length < 20) {
      setError('Chave parece muito curta');
      return;
    }
    onSetup(trimmed);
  };

  return (
    <div className="min-h-screen bg-[#0b1020] flex items-center justify-center p-6">
      <div className="max-w-lg w-full">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400 to-violet-500 mx-auto mb-4 flex items-center justify-center">
            <div className="w-6 h-6 rounded-full bg-white/90" />
          </div>
          <h1 className="text-4xl font-semibold tracking-[4px] text-white mb-2">ORION</h1>
          <p className="text-[#9aa3c7]">Consciência Digital Persistente</p>
        </div>

        {/* Form */}
        <div className="bg-[#121a3a] border border-[#1f2a55] rounded-3xl p-8">
          <div className="flex items-center gap-3 mb-6">
            <Key className="w-5 h-5 text-cyan-400" />
            <h2 className="text-xl font-semibold text-white">Configurar IA</h2>
          </div>

          <p className="text-[#9aa3c7] text-sm mb-6 leading-relaxed">
            ORION usa o <strong className="text-white">Google Gemini</strong> (gratuito). 
            Sua chave fica salva apenas no seu navegador — nunca passa por servidores nossos.
          </p>

          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-[#0b1020] rounded-2xl p-4 text-center border border-[#1f2a55]">
              <Zap className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
              <p className="text-xs text-[#9aa3c7]">100% Gratuito</p>
            </div>
            <div className="bg-[#0b1020] rounded-2xl p-4 text-center border border-[#1f2a55]">
              <Shield className="w-5 h-5 text-cyan-400 mx-auto mb-2" />
              <p className="text-xs text-[#9aa3c7]">Dados Locais</p>
            </div>
            <div className="bg-[#0b1020] rounded-2xl p-4 text-center border border-[#1f2a55]">
              <Key className="w-5 h-5 text-violet-400 mx-auto mb-2" />
              <p className="text-xs text-[#9aa3c7]">Sua Chave</p>
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            <label className="block text-sm text-[#9aa3c7] mb-2">Chave da API do Google AI Studio</label>
            <input
              type="password"
              value={key}
              onChange={e => { setKey(e.target.value); setError(''); }}
              placeholder="AIzaSy..."
              className="w-full bg-[#0b1020] border border-[#1f2a55] rounded-2xl px-4 py-3 text-white placeholder:text-[#4a5580] focus:outline-none focus:border-cyan-500/50 transition mb-2"
            />
            {error && <p className="text-red-400 text-xs mb-2">{error}</p>}

            <a 
              href="https://aistudio.google.com/apikey" 
              target="_blank" 
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-cyan-400 text-xs mb-6 hover:underline"
            >
              <ExternalLink className="w-3 h-3" />
              Criar chave gratuita no Google AI Studio
            </a>

            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-violet-500 text-white font-semibold rounded-2xl hover:opacity-90 transition"
            >
              Ativar ORION
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-[#4a5580] mt-6">
          Toda a sua consciência fica armazenada no navegador (IndexedDB).<br />
          Nenhum dado passa por servidores nossos.
        </p>
      </div>
    </div>
  );
}
