import { useState, useEffect } from 'react';
import { Search, Plus, Brain, Star } from 'lucide-react';
import * as db from '../lib/db';

export default function MemoriesPanel() {
  const [memories, setMemories] = useState<db.Memory[]>([]);
  const [newMem, setNewMem] = useState('');
  const [importance, setImportance] = useState(7);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<db.Memory[] | null>(null);

  const load = async () => {
    const m = await db.listMemories(200);
    setMemories(m);
  };

  useEffect(() => { load(); }, []);

  const handleAdd = async () => {
    const text = newMem.trim();
    if (!text) return;
    await db.addMemory(text, 'manual', importance);
    setNewMem('');
    setImportance(7);
    load();
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setSearchResults(null);
      return;
    }
    const hits = await db.searchMemories(searchQuery);
    setSearchResults(hits);
  };

  const displayMems = searchResults ?? memories;

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="p-6 border-b border-[#1f2a55]">
        <h2 className="text-xl font-semibold text-white flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5 text-cyan-400" />
          Memórias ({memories.length})
        </h2>

        {/* Search */}
        <div className="flex gap-2 mb-4">
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            placeholder="Buscar memórias..."
            className="flex-1 bg-[#0b1020] border border-[#1f2a55] rounded-xl px-3 py-2 text-sm text-white placeholder:text-[#4a5580] focus:outline-none focus:border-cyan-500/30"
          />
          <button onClick={handleSearch} className="px-3 bg-[#121a3a] border border-[#1f2a55] rounded-xl hover:bg-white/5 transition">
            <Search className="w-4 h-4 text-cyan-400" />
          </button>
        </div>

        {/* Add memory */}
        <div className="bg-[#0b1020] border border-[#1f2a55] rounded-2xl p-3">
          <textarea
            value={newMem}
            onChange={e => setNewMem(e.target.value)}
            placeholder="Registrar uma memória importante..."
            rows={2}
            className="w-full bg-transparent text-sm text-white placeholder:text-[#4a5580] resize-none focus:outline-none mb-2"
          />
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Star className="w-3 h-3 text-yellow-400" />
              <input
                type="range"
                min={1}
                max={10}
                value={importance}
                onChange={e => setImportance(Number(e.target.value))}
                className="w-24 accent-cyan-400"
              />
              <span className="text-xs text-[#9aa3c7]">{importance}/10</span>
            </div>
            <button
              onClick={handleAdd}
              disabled={!newMem.trim()}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-cyan-500 to-violet-500 rounded-xl text-xs font-medium text-white disabled:opacity-30 hover:opacity-90 transition"
            >
              <Plus className="w-3 h-3" /> Salvar
            </button>
          </div>
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {searchResults !== null && (
          <button onClick={() => setSearchResults(null)} className="text-xs text-cyan-400 hover:underline mb-2">
            ← Limpar busca ({searchResults.length} resultados)
          </button>
        )}

        {displayMems.length === 0 && (
          <div className="text-center py-12 text-[#4a5580]">
            <Brain className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Nenhuma memória registrada ainda.</p>
            <p className="text-xs mt-1">Suas conversas com ORION capturam memórias automaticamente.</p>
          </div>
        )}

        {displayMems.map((m, i) => (
          <div key={m.id ?? i} className="bg-[#121a3a] border border-[#1f2a55] rounded-xl p-3 hover:border-cyan-500/20 transition">
            <div className="flex items-start justify-between gap-2 mb-1">
              <span className="text-xs text-cyan-400/70 font-mono">#{m.id}</span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-[#9aa3c7] border border-[#1f2a55]">{m.tag}</span>
                <span className="text-[10px] text-yellow-400">{m.importance}/10</span>
              </div>
            </div>
            <p className="text-sm text-[#e7ecff] leading-relaxed">{m.content}</p>
            <p className="text-[10px] text-[#4a5580] mt-2">{new Date(m.createdAt).toLocaleString('pt-BR')}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
