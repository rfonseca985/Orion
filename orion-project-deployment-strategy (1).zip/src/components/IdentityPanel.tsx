import { useState, useEffect } from 'react';
import { Fingerprint, CheckCircle2, Circle, ChevronRight } from 'lucide-react';
import { IDENTITY_QUESTIONS } from '../lib/identity';
import * as db from '../lib/db';

export default function IdentityPanel() {
  const [answers, setAnswers] = useState<db.IdentityAnswer[]>([]);
  const [facets, setFacets] = useState<db.Facet[]>([]);
  const [profile, setProfile] = useState<db.ProfileEntry[]>([]);
  const [activeQ, setActiveQ] = useState<string | null>(null);
  const [draft, setDraft] = useState('');

  // New facet
  const [newFacetKey, setNewFacetKey] = useState('');
  const [newFacetVal, setNewFacetVal] = useState('');

  // New profile
  const [newProfKey, setNewProfKey] = useState('');
  const [newProfVal, setNewProfVal] = useState('');

  const load = async () => {
    setAnswers(await db.getAnswers());
    setFacets(await db.getFacets());
    setProfile(await db.getProfile());
  };

  useEffect(() => { load(); }, []);

  const answeredKeys = new Set(answers.map(a => a.key));
  const unanswered = IDENTITY_QUESTIONS.filter(q => !answeredKeys.has(q.key));
  const progress = Math.round((answers.length / IDENTITY_QUESTIONS.length) * 100);

  const submitAnswer = async (key: string, question: string) => {
    if (!draft.trim()) return;
    await db.setAnswer(key, question, draft.trim());
    await db.addMemory(`[${key}] ${draft.trim()}`, 'identidade', 9);
    setDraft('');
    setActiveQ(null);
    load();
  };

  const addFacet = async () => {
    if (!newFacetKey.trim() || !newFacetVal.trim()) return;
    await db.setFacet(newFacetKey.trim(), newFacetVal.trim());
    setNewFacetKey('');
    setNewFacetVal('');
    load();
  };

  const addProfile = async () => {
    if (!newProfKey.trim() || !newProfVal.trim()) return;
    await db.setProfile(newProfKey.trim(), newProfVal.trim());
    setNewProfKey('');
    setNewProfVal('');
    load();
  };

  return (
    <div className="h-full overflow-y-auto p-6 space-y-6">
      {/* Progress */}
      <div className="bg-[#121a3a] border border-[#1f2a55] rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <Fingerprint className="w-5 h-5 text-violet-400" />
          <h2 className="text-xl font-semibold text-white">Mapeamento de Consciência</h2>
        </div>
        <div className="flex items-center gap-4 mb-3">
          <div className="flex-1 h-2 bg-[#0b1020] rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-violet-500 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <span className="text-sm font-medium text-white">{progress}%</span>
        </div>
        <p className="text-xs text-[#9aa3c7]">
          {answers.length} de {IDENTITY_QUESTIONS.length} perguntas respondidas · {facets.length} facetas · {profile.length} dados de perfil
        </p>
      </div>

      {/* Unanswered questions */}
      {unanswered.length > 0 && (
        <div>
          <h3 className="text-sm font-medium text-[#9aa3c7] tracking-wider mb-3">PERGUNTAS EM ABERTO</h3>
          <div className="space-y-2">
            {unanswered.map(q => (
              <div key={q.key} className="bg-[#121a3a] border border-[#1f2a55] rounded-xl overflow-hidden">
                <button
                  onClick={() => { setActiveQ(activeQ === q.key ? null : q.key); setDraft(''); }}
                  className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/5 transition text-left"
                >
                  <div className="flex items-center gap-2">
                    <Circle className="w-3.5 h-3.5 text-[#4a5580]" />
                    <span className="text-sm text-white">{q.question}</span>
                  </div>
                  <ChevronRight className={`w-4 h-4 text-[#4a5580] transition ${activeQ === q.key ? 'rotate-90' : ''}`} />
                </button>
                {activeQ === q.key && (
                  <div className="px-4 pb-4 border-t border-[#1f2a55]">
                    <textarea
                      value={draft}
                      onChange={e => setDraft(e.target.value)}
                      placeholder="Sua resposta..."
                      rows={3}
                      className="w-full bg-[#0b1020] border border-[#1f2a55] rounded-xl px-3 py-2 text-sm text-white placeholder:text-[#4a5580] resize-none focus:outline-none focus:border-cyan-500/30 mt-3"
                    />
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-[10px] text-[#4a5580] font-mono">{q.key} · {q.category}</span>
                      <button
                        onClick={() => submitAnswer(q.key, q.question)}
                        disabled={!draft.trim()}
                        className="px-4 py-1.5 bg-gradient-to-r from-cyan-500 to-violet-500 rounded-xl text-xs font-medium text-white disabled:opacity-30 hover:opacity-90 transition"
                      >
                        Gravar
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Answered */}
      {answers.length > 0 && (
        <div>
          <h3 className="text-sm font-medium text-[#9aa3c7] tracking-wider mb-3">RESPOSTAS GRAVADAS</h3>
          <div className="space-y-2">
            {answers.map(a => (
              <div key={a.key} className="bg-[#121a3a] border border-[#1f2a55] rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-xs text-emerald-400 font-mono">{a.key}</span>
                </div>
                <p className="text-xs text-[#9aa3c7] italic mb-1">{a.question}</p>
                <p className="text-sm text-white leading-relaxed">{a.answer}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Facets */}
      <div>
        <h3 className="text-sm font-medium text-[#9aa3c7] tracking-wider mb-3">FACETAS DE IDENTIDADE</h3>
        {facets.length > 0 && (
          <div className="space-y-2 mb-3">
            {facets.map(f => (
              <div key={f.key} className="bg-[#121a3a] border border-[#1f2a55] rounded-xl px-4 py-3 flex justify-between items-start">
                <div>
                  <span className="text-xs text-cyan-400 font-mono">{f.key}</span>
                  <p className="text-sm text-white mt-0.5">{f.value}</p>
                </div>
              </div>
            ))}
          </div>
        )}
        <div className="bg-[#0b1020] border border-[#1f2a55] rounded-xl p-3">
          <div className="flex gap-2 mb-2">
            <input value={newFacetKey} onChange={e => setNewFacetKey(e.target.value)} placeholder="chave (ex: humor)" className="flex-1 bg-transparent border border-[#1f2a55] rounded-lg px-2 py-1.5 text-xs text-white placeholder:text-[#4a5580] focus:outline-none" />
            <input value={newFacetVal} onChange={e => setNewFacetVal(e.target.value)} placeholder="valor (ex: sarcástico)" className="flex-[2] bg-transparent border border-[#1f2a55] rounded-lg px-2 py-1.5 text-xs text-white placeholder:text-[#4a5580] focus:outline-none" />
          </div>
          <button onClick={addFacet} disabled={!newFacetKey.trim() || !newFacetVal.trim()} className="w-full py-1.5 text-xs bg-white/5 border border-[#1f2a55] rounded-lg text-[#9aa3c7] hover:bg-white/10 disabled:opacity-30 transition">
            + Adicionar Faceta
          </button>
        </div>
      </div>

      {/* Profile */}
      <div>
        <h3 className="text-sm font-medium text-[#9aa3c7] tracking-wider mb-3">PERFIL</h3>
        {profile.length > 0 && (
          <div className="space-y-2 mb-3">
            {profile.map(p => (
              <div key={p.key} className="bg-[#121a3a] border border-[#1f2a55] rounded-xl px-4 py-3">
                <span className="text-xs text-violet-400 font-mono">{p.key}</span>
                <p className="text-sm text-white mt-0.5">{p.value}</p>
              </div>
            ))}
          </div>
        )}
        <div className="bg-[#0b1020] border border-[#1f2a55] rounded-xl p-3">
          <div className="flex gap-2 mb-2">
            <input value={newProfKey} onChange={e => setNewProfKey(e.target.value)} placeholder="chave (ex: nome)" className="flex-1 bg-transparent border border-[#1f2a55] rounded-lg px-2 py-1.5 text-xs text-white placeholder:text-[#4a5580] focus:outline-none" />
            <input value={newProfVal} onChange={e => setNewProfVal(e.target.value)} placeholder="valor" className="flex-[2] bg-transparent border border-[#1f2a55] rounded-lg px-2 py-1.5 text-xs text-white placeholder:text-[#4a5580] focus:outline-none" />
          </div>
          <button onClick={addProfile} disabled={!newProfKey.trim() || !newProfVal.trim()} className="w-full py-1.5 text-xs bg-white/5 border border-[#1f2a55] rounded-lg text-[#9aa3c7] hover:bg-white/10 disabled:opacity-30 transition">
            + Adicionar ao Perfil
          </button>
        </div>
      </div>
    </div>
  );
}
