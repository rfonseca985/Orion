import { useState } from 'react';
import { Download, FileText, Shield, Trash2, AlertTriangle } from 'lucide-react';
import * as db from '../lib/db';

interface Props {
  onResetKey: () => void;
}

export default function LegacyPanel({ onResetKey }: Props) {
  const [exporting, setExporting] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleExport = async () => {
    setExporting(true);
    try {
      const md = await db.exportAllData();
      const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `orion_legado_${new Date().toISOString().slice(0, 10)}.md`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    } finally {
      setExporting(false);
    }
  };

  const handleExportJSON = async () => {
    const memories = await db.listMemories(10000);
    const messages = await db.recentMessages(10000);
    const facets = await db.getFacets();
    const profile = await db.getProfile();
    const answers = await db.getAnswers();
    const data = { memories, messages, facets, profile, answers, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `orion_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleReset = () => {
    indexedDB.deleteDatabase('orion_consciousness');
    localStorage.removeItem('orion_api_key');
    window.location.reload();
  };

  return (
    <div className="h-full overflow-y-auto p-6 space-y-6">
      <h2 className="text-xl font-semibold text-white flex items-center gap-2">
        <Shield className="w-5 h-5 text-cyan-400" />
        Legado e Configurações
      </h2>

      {/* Export */}
      <div className="bg-[#121a3a] border border-[#1f2a55] rounded-2xl p-6">
        <h3 className="font-medium text-white mb-3">Exportar Consciência</h3>
        <p className="text-sm text-[#9aa3c7] mb-4">
          Baixe toda a sua consciência digital — memórias, identidade, perfil e conversas.
        </p>
        <div className="flex gap-3">
          <button
            onClick={handleExport}
            disabled={exporting}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-violet-500 rounded-xl text-sm font-medium text-white hover:opacity-90 transition disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            {exporting ? 'Exportando...' : 'Markdown (.md)'}
          </button>
          <button
            onClick={handleExportJSON}
            className="flex items-center gap-2 px-4 py-2.5 bg-white/5 border border-[#1f2a55] rounded-xl text-sm text-white hover:bg-white/10 transition"
          >
            <FileText className="w-4 h-4" />
            Backup (.json)
          </button>
        </div>
      </div>

      {/* API Key */}
      <div className="bg-[#121a3a] border border-[#1f2a55] rounded-2xl p-6">
        <h3 className="font-medium text-white mb-3">Chave de API</h3>
        <p className="text-sm text-[#9aa3c7] mb-4">
          Sua chave do Google AI Studio está salva localmente no navegador.
        </p>
        <button
          onClick={onResetKey}
          className="flex items-center gap-2 px-4 py-2.5 bg-white/5 border border-[#1f2a55] rounded-xl text-sm text-white hover:bg-white/10 transition"
        >
          Trocar chave de API
        </button>
      </div>

      {/* Privacy Info */}
      <div className="bg-[#121a3a] border border-[#1f2a55] rounded-2xl p-6">
        <h3 className="font-medium text-white mb-3">Privacidade</h3>
        <ul className="text-sm text-[#9aa3c7] space-y-2">
          <li>• Toda a consciência fica em <strong className="text-white">IndexedDB</strong> (seu navegador).</li>
          <li>• Sua chave de API fica em <strong className="text-white">localStorage</strong> (seu navegador).</li>
          <li>• As conversas vão ao <strong className="text-white">Google Gemini</strong> via sua chave pessoal.</li>
          <li>• Nenhum servidor intermediário tem acesso aos seus dados.</li>
          <li>• Para preservação permanente, faça backups regulares.</li>
        </ul>
      </div>

      {/* Danger zone */}
      <div className="bg-red-950/20 border border-red-500/20 rounded-2xl p-6">
        <h3 className="font-medium text-red-300 flex items-center gap-2 mb-3">
          <AlertTriangle className="w-4 h-4" />
          Zona de Risco
        </h3>
        {!confirmReset ? (
          <button
            onClick={() => setConfirmReset(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-red-500/10 border border-red-500/20 rounded-xl text-sm text-red-300 hover:bg-red-500/20 transition"
          >
            <Trash2 className="w-4 h-4" />
            Apagar toda a consciência
          </button>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-red-300">
              ⚠️ Isso apagará TODAS as memórias, conversas, identidade e perfil. 
              Faça backup antes. Essa ação é irreversível.
            </p>
            <div className="flex gap-3">
              <button
                onClick={handleReset}
                className="px-4 py-2 bg-red-600 rounded-xl text-sm font-medium text-white hover:bg-red-700 transition"
              >
                Confirmar — Apagar Tudo
              </button>
              <button
                onClick={() => setConfirmReset(false)}
                className="px-4 py-2 bg-white/5 border border-[#1f2a55] rounded-xl text-sm text-white hover:bg-white/10 transition"
              >
                Cancelar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
