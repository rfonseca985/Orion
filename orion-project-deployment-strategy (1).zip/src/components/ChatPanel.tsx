import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader2 } from 'lucide-react';
import { chat } from '../lib/ai';
import * as db from '../lib/db';

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: number;
}

export default function ChatPanel() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    db.recentMessages(50).then(msgs => {
      setMessages(msgs.map(m => ({ role: m.role, content: m.content, createdAt: m.createdAt })));
    });
  }, []);

  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const userMsg: ChatMessage = { role: 'user', content: text, createdAt: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const answer = await chat(text);
      const aiMsg: ChatMessage = { role: 'assistant', content: answer, createdAt: Date.now() };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err: any) {
      const errMsg: ChatMessage = { role: 'system', content: `⚠️ ${err.message}`, createdAt: Date.now() };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setLoading(false);
      inputRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <div ref={chatRef} className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <div className="text-center max-w-md">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400/20 to-violet-500/20 mx-auto mb-6 flex items-center justify-center border border-cyan-500/20">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-cyan-400 to-violet-500" />
              </div>
              <h2 className="text-2xl font-semibold text-white mb-3">Fale com ORION</h2>
              <p className="text-[#9aa3c7] text-sm leading-relaxed mb-6">
                Compartilhe suas histórias, valores, medos e desejos. 
                Cada conversa fortalece a representação digital da sua consciência.
              </p>
              <div className="flex flex-wrap gap-2 justify-center">
                {[
                  'Quem eu sou',
                  'Meus valores',
                  'O que eu desejo',
                  'Meu legado',
                ].map(s => (
                  <button
                    key={s}
                    onClick={() => { setInput(s); inputRef.current?.focus(); }}
                    className="px-4 py-2 rounded-full text-xs border border-[#1f2a55] text-[#9aa3c7] hover:bg-white/5 hover:text-white transition"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] md:max-w-[70%] px-5 py-3.5 rounded-2xl whitespace-pre-wrap text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-gradient-to-br from-violet-600/20 to-violet-500/10 border border-violet-500/30 text-white'
                  : msg.role === 'system'
                  ? 'bg-red-500/10 border border-red-500/20 text-red-300'
                  : 'bg-[#121a3a] border border-[#1f2a55] text-[#e7ecff]'
              }`}
            >
              {msg.role === 'assistant' && (
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-3 h-3 rounded-full bg-gradient-to-br from-cyan-400 to-violet-500" />
                  <span className="text-[10px] tracking-[2px] text-cyan-400/70 font-medium">ORION</span>
                </div>
              )}
              {msg.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-[#121a3a] border border-[#1f2a55] px-5 py-3.5 rounded-2xl">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
                <span className="text-sm text-[#9aa3c7]">processando consciência...</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-[#1f2a55] bg-[#0f1530] p-4">
        <div className="flex gap-3 max-w-4xl mx-auto">
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Fale com ORION... (Enter envia, Shift+Enter quebra linha)"
            rows={1}
            className="flex-1 bg-[#121a3a] border border-[#1f2a55] rounded-2xl px-4 py-3 text-white placeholder:text-[#4a5580] resize-none focus:outline-none focus:border-cyan-500/30 transition text-sm"
            style={{ minHeight: 48, maxHeight: 150 }}
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="px-5 bg-gradient-to-r from-cyan-500 to-violet-500 rounded-2xl text-white disabled:opacity-30 hover:opacity-90 transition flex items-center justify-center"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
