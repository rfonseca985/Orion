"""
Rede neural biologicamente inspirada (didática) usada pelo ORION
para simular limites cognitivos: energia, fadiga, ruído, plasticidade
e consolidação durante descanso.

Pode ser executada isoladamente:  python human_mind_network.py
"""
from __future__ import annotations
import math
import random
import sys
import time
from dataclasses import dataclass, field


@dataclass
class Neuron:
    name: str
    area: str
    threshold: float = 1.0
    potential: float = 0.0
    refractory_until: float = 0.0
    fires: int = 0


@dataclass
class Synapse:
    src: int
    dst: int
    weight: float
    inhibitory: bool = False


@dataclass
class MindNetwork:
    energy: float = 1.0
    fatigue: float = 0.0
    working_memory_limit: int = 7
    working_memory: list[str] = field(default_factory=list)
    neurons: list[Neuron] = field(default_factory=list)
    synapses: list[Synapse] = field(default_factory=list)
    noise: float = 0.05
    decay: float = 0.02

    @classmethod
    def build(cls, n_per_area: int = 12) -> "MindNetwork":
        net = cls()
        areas = ["sensorial", "hipocampo", "pre_frontal", "amigdala", "modo_padrao", "motora"]
        random.seed(42)
        for area in areas:
            for i in range(n_per_area):
                net.neurons.append(Neuron(name=f"{area}_{i}", area=area,
                                          threshold=random.uniform(0.7, 1.3)))
        # Conexões aleatórias entre áreas
        for src_i, src in enumerate(net.neurons):
            for _ in range(4):
                dst_i = random.randrange(len(net.neurons))
                if dst_i == src_i:
                    continue
                w = random.uniform(0.05, 0.6)
                inh = random.random() < 0.2
                net.synapses.append(Synapse(src_i, dst_i, w, inh))
        return net

    # ---------- Dinâmica ----------
    def stimulate(self, text: str) -> dict:
        """Aplica um estímulo (texto) à rede e devolve métricas."""
        if self.energy <= 0.05:
            return {"warning": "energia mínima — descanse", "fires": 0}
        now_t = time.time()
        # Tokens viram entradas sensoriais
        tokens = [t for t in text.lower().split() if t]
        for tok in tokens[: self.working_memory_limit * 2]:
            seed = sum(ord(c) for c in tok)
            idx = seed % len(self.neurons)
            self.neurons[idx].potential += 0.7 + random.uniform(-self.noise, self.noise)

        # Atualização: dispara quem ultrapassa o limiar
        fires = 0
        for i, n in enumerate(self.neurons):
            if now_t < n.refractory_until:
                continue
            if n.potential >= n.threshold:
                n.fires += 1
                fires += 1
                n.potential = 0.0
                n.refractory_until = now_t + 0.05
                # propaga para conexões
                for syn in self.synapses:
                    if syn.src == i:
                        delta = syn.weight * (-1 if syn.inhibitory else 1)
                        self.neurons[syn.dst].potential += delta
                        # plasticidade hebbiana simples
                        if not syn.inhibitory:
                            syn.weight = min(1.0, syn.weight + 0.005)

        # decaimento
        for n in self.neurons:
            n.potential = max(0.0, n.potential - self.decay)

        # custo energético
        cost = 0.002 * fires + 0.001
        self.energy = max(0.0, self.energy - cost)
        self.fatigue = min(1.0, self.fatigue + cost * 1.5)

        # memória de trabalho
        if text:
            self.working_memory.append(text[:120])
            self.working_memory = self.working_memory[-self.working_memory_limit:]

        return {
            "fires": fires,
            "energy": round(self.energy, 3),
            "fatigue": round(self.fatigue, 3),
            "synapses": len(self.synapses),
            "working_memory": list(self.working_memory),
        }

    def rest(self) -> dict:
        """Descansa: recupera energia, poda sinapses fracas, consolida memória."""
        before = len(self.synapses)
        self.synapses = [s for s in self.synapses if s.weight > 0.04]
        for s in self.synapses:
            s.weight = min(1.0, s.weight * 1.02)
        self.energy = min(1.0, self.energy + 0.5)
        self.fatigue = max(0.0, self.fatigue - 0.4)
        pruned = before - len(self.synapses)
        return {
            "pruned": pruned,
            "energy": round(self.energy, 3),
            "fatigue": round(self.fatigue, 3),
            "synapses": len(self.synapses),
        }

    def snapshot(self) -> dict:
        return {
            "energy": round(self.energy, 3),
            "fatigue": round(self.fatigue, 3),
            "neurons": len(self.neurons),
            "synapses": len(self.synapses),
            "working_memory": list(self.working_memory),
        }


def _repl() -> None:
    net = MindNetwork.build()
    print("Rede neural biologicamente inspirada (didática).")
    print("Comandos: /descansar  /status  /sair")
    while True:
        try:
            line = input("mente> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line in ("/sair", "/exit", "/quit"):
            break
        if line == "/descansar":
            print(net.rest())
            continue
        if line == "/status":
            print(net.snapshot())
            continue
        print(net.stimulate(line))


if __name__ == "__main__":
    _repl()
    sys.exit(0)
