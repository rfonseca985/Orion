"""
Backup criptografado do banco do ORION.

Uso:
    python backup_orion.py                          # salva em exports/
    python backup_orion.py "/caminho/orion.orionenc"

Variáveis de ambiente:
    ORION_BACKUP_PASSPHRASE   senha do backup (se ausente, o script pergunta)
"""
from __future__ import annotations
import datetime as dt
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from orion_core.config import DB_PATH, EXPORTS_DIR, ORION_BACKUP_PASSPHRASE
from orion_core.crypto import decrypt, encrypt


def make_backup(out_path: str | None = None, passphrase: str | None = None) -> Path:
    pw = passphrase or ORION_BACKUP_PASSPHRASE
    if not pw:
        pw = getpass.getpass("Senha do backup (não fica salva): ").strip()
    if not pw:
        raise RuntimeError("Senha vazia. Abortando.")

    if not DB_PATH.exists():
        raise FileNotFoundError(f"Banco não existe ainda: {DB_PATH}")

    raw = DB_PATH.read_bytes()
    blob = encrypt(raw, pw)
    if out_path:
        out = Path(out_path).expanduser()
    else:
        ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        out = EXPORTS_DIR / f"orion_backup_{ts}.orionenc"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(blob)
    return out


def restore_backup(in_path: str, target: str | None = None, passphrase: str | None = None) -> Path:
    pw = passphrase or ORION_BACKUP_PASSPHRASE or getpass.getpass("Senha do backup: ").strip()
    blob = Path(in_path).read_bytes()
    raw = decrypt(blob, pw)
    out = Path(target).expanduser() if target else DB_PATH
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(raw)
    return out


def main() -> None:
    args = sys.argv[1:]
    if args and args[0] in ("--restore", "-r"):
        if len(args) < 2:
            print("Uso: python backup_orion.py --restore <arquivo.orionenc> [destino.sqlite3]")
            sys.exit(2)
        out = restore_backup(args[1], args[2] if len(args) > 2 else None)
        print(f"♻️  banco restaurado em: {out}")
        return
    out_path = args[0] if args else None
    out = make_backup(out_path)
    print(f"🔐 backup criptografado salvo em: {out}")


if __name__ == "__main__":
    main()
