"""
Interface web local do ORION (stdlib pura).

Sobe um servidor em http://127.0.0.1:8765 com chat, memórias e identidade.
Nenhum dado sai da sua máquina.

Uso:  python web_orion.py
"""
from __future__ import annotations
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))

from orion_core import memory, orion_brain
from orion_core.config import DEFAULT_MODEL, WEB_HOST, WEB_PORT
from orion_core.ollama_client import OllamaError, list_models, ping


INDEX_HTML = r"""<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"/>
<title>ORION — local</title>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<style>
:root{--bg:#0b1020;--bg2:#0f1530;--fg:#e7ecff;--muted:#9aa3c7;--accent:#00e0ff;--accent2:#7c5cff;--card:#121a3a;--border:#1f2a55;--code:#0a0f25}
*{box-sizing:border-box}
html,body{margin:0;height:100%;background:var(--bg);color:var(--fg);font-family:-apple-system,Segoe UI,Roboto,Inter,sans-serif}
header{display:flex;align-items:center;justify-content:space-between;padding:12px 20px;border-bottom:1px solid var(--border);background:linear-gradient(180deg,var(--bg2),var(--bg))}
.logo{display:flex;align-items:center;gap:10px;font-weight:700;letter-spacing:.18em}
.logo .dot{width:16px;height:16px;border-radius:50%;background:radial-gradient(circle at 30% 30%,#fff,var(--accent) 55%,#0b1020 100%);box-shadow:0 0 18px rgba(0,224,255,.6)}
.status{font-size:13px;color:var(--muted)}
.layout{display:grid;grid-template-columns:280px 1fr;height:calc(100% - 56px)}
aside{border-right:1px solid var(--border);padding:14px;overflow:auto;background:var(--bg2)}
aside h3{margin:14px 0 8px;font-size:12px;letter-spacing:.18em;color:var(--muted);text-transform:uppercase}
aside button,aside .item{display:block;width:100%;text-align:left;background:transparent;border:1px solid var(--border);color:var(--fg);padding:8px 10px;border-radius:8px;margin-bottom:6px;cursor:pointer;font:inherit}
aside button:hover{border-color:var(--accent)}
main{display:flex;flex-direction:column;min-width:0}
#chat{flex:1;overflow:auto;padding:20px;display:flex;flex-direction:column;gap:14px}
.msg{max-width:780px;padding:12px 14px;border-radius:12px;border:1px solid var(--border);white-space:pre-wrap;line-height:1.5}
.msg.user{align-self:flex-end;background:rgba(124,92,255,.12);border-color:rgba(124,92,255,.4)}
.msg.assistant{align-self:flex-start;background:rgba(0,224,255,.06);border-color:rgba(0,224,255,.3)}
.msg.system{align-self:center;font-size:13px;color:var(--muted);background:transparent;border-style:dashed}
form{display:flex;gap:8px;padding:12px;border-top:1px solid var(--border);background:var(--bg2)}
textarea{flex:1;background:var(--code);color:var(--fg);border:1px solid var(--border);border-radius:10px;padding:10px;resize:none;font:inherit;min-height:48px;max-height:160px}
button.send{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#08102a;border:none;border-radius:10px;padding:0 18px;font-weight:700;cursor:pointer}
.small{font-size:12px;color:var(--muted)}
.tag{display:inline-block;background:rgba(0,224,255,.1);color:var(--accent);padding:2px 8px;border-radius:999px;font-size:11px;border:1px solid rgba(0,224,255,.3);margin-right:6px}
input[type=text]{width:100%;background:var(--code);color:var(--fg);border:1px solid var(--border);border-radius:8px;padding:8px;font:inherit}
.row{display:flex;gap:6px}
</style></head>
<body>
<header>
  <div class="logo"><span class="dot"></span> ORION</div>
  <div class="status" id="status">conectando…</div>
</header>
<div class="layout">
  <aside>
    <h3>Ações rápidas</h3>
    <button onclick="loadMems()">📚 Memórias</button>
    <button onclick="loadEu()">🧬 Meu eu</button>
    <button onclick="nextQ()">❓ Próxima pergunta</button>
    <button onclick="resumo()">📜 Resumo</button>
    <button onclick="exportar()">📤 Exportar legado</button>

    <h3>Lembrar agora</h3>
    <div class="row"><input id="memInput" type="text" placeholder="texto…"/></div>
    <button onclick="addMem()">Salvar memória</button>

    <h3>Buscar (semântica)</h3>
    <div class="row"><input id="semInput" type="text" placeholder="conceito…"/></div>
    <button onclick="sem()">Buscar</button>

    <h3>Modelo</h3>
    <div class="small" id="modelInfo">…</div>
  </aside>
  <main>
    <div id="chat"></div>
    <form id="form">
      <textarea id="input" placeholder="fale com ORION… (Enter envia, Shift+Enter quebra linha)"></textarea>
      <button class="send" type="submit">Enviar</button>
    </form>
  </main>
</div>
<script>
const chat = document.getElementById('chat');
const form = document.getElementById('form');
const input = document.getElementById('input');
function add(role, text){
  const d = document.createElement('div');
  d.className = 'msg ' + role;
  d.textContent = text;
  chat.appendChild(d);
  chat.scrollTop = chat.scrollHeight;
  return d;
}
async function api(path, opts){
  const r = await fetch(path, opts);
  return await r.json();
}
async function refreshStatus(){
  const s = await api('/api/status');
  document.getElementById('status').textContent =
    (s.ollama ? '🟢 Ollama OK' : '🔴 Ollama offline') + ' · ' + s.model + ' · ' + (s.secure ? '🔒 cifrado' : '🔓 plano');
  document.getElementById('modelInfo').textContent = s.model + ' · ' + (s.models||[]).length + ' modelos locais';
}
form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const text = input.value.trim();
  if(!text) return;
  add('user', text);
  input.value = '';
  const placeholder = add('assistant', '…pensando…');
  try{
    const r = await api('/api/chat', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({message: text})});
    placeholder.textContent = r.answer || '(sem resposta)';
    if(r.next_question){
      add('system', 'pergunta identitária — [' + r.next_question.key + '] ' + r.next_question.question);
    }
  }catch(err){
    placeholder.textContent = '⚠️ erro: ' + err;
  }
});
input.addEventListener('keydown', (e)=>{
  if(e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); form.requestSubmit(); }
});
async function loadMems(){
  const r = await api('/api/memories');
  add('system', '📚 ' + r.memories.length + ' memórias');
  r.memories.slice(0,10).forEach(m=>{
    add('assistant', (m.encrypted?'🔒 ':'') + '#' + m.id + ' (' + m.importance + '/10) ' + m.content);
  });
}
async function loadEu(){
  const r = await api('/api/eu');
  let s = 'Facetas:\n';
  for(const k in r.facets) s += '  - ' + k + ': ' + r.facets[k] + '\n';
  s += '\nRespostas:\n';
  for(const k in r.answers) s += '  - ' + k + ': ' + r.answers[k].answer + '\n';
  add('system', s || '(eu vazio — rode capturar_eu.py)');
}
async function nextQ(){
  const r = await api('/api/next-question');
  if(r.question) add('system', '[' + r.question.key + '] ' + r.question.question);
  else add('system', '✓ sem perguntas em aberto');
}
async function resumo(){
  add('system', '📜 pedindo resumo…');
  const r = await api('/api/resumo', {method:'POST'});
  add('assistant', r.answer);
}
async function exportar(){
  const r = await api('/api/export', {method:'POST'});
  add('system', '📤 exportado: ' + r.path);
}
async function addMem(){
  const v = document.getElementById('memInput').value.trim();
  if(!v) return;
  const r = await api('/api/memories', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({content:v, importance:7})});
  add('system', '🧠 memória #' + r.id + ' salva');
  document.getElementById('memInput').value='';
}
async function sem(){
  const q = document.getElementById('semInput').value.trim();
  if(!q) return;
  const r = await api('/api/semantic?q=' + encodeURIComponent(q));
  if(!r.hits.length){ add('system','(nada encontrado)'); return; }
  r.hits.forEach(h=> add('assistant', h.score.toFixed(2)+'  #'+h.memory.id+' — '+h.memory.content.slice(0,200)));
}
refreshStatus();
setInterval(refreshStatus, 10000);
</script>
</body></html>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):  # silencia logs ruidosos
        return

    # ---------- helpers ----------
    def _json(self, code: int, obj: dict) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or "0")
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return {}

    # ---------- routing ----------
    def do_GET(self):
        url = urlparse(self.path)
        if url.path in ("/", "/index.html"):
            body = INDEX_HTML.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if url.path == "/api/status":
            from orion_core.config import ORION_PASSPHRASE
            return self._json(200, {
                "ollama": ping(),
                "model": DEFAULT_MODEL,
                "models": list_models(),
                "secure": bool(ORION_PASSPHRASE),
            })
        if url.path == "/api/memories":
            return self._json(200, {"memories": memory.list_memories(limit=200)})
        if url.path == "/api/eu":
            return self._json(200, {"facets": memory.get_facets(), "answers": memory.get_answers()})
        if url.path == "/api/next-question":
            q = memory.next_open_question()
            return self._json(200, {"question": ({"key": q[0], "question": q[1]} if q else None)})
        if url.path == "/api/semantic":
            from urllib.parse import parse_qs
            qs = parse_qs(url.query)
            query = (qs.get("q") or [""])[0]
            hits = memory.semantic_search(query, k=8)
            return self._json(200, {"hits": [{"score": s, "memory": m} for s, m in hits]})
        return self._json(404, {"error": "not found"})

    def do_POST(self):
        url = urlparse(self.path)
        if url.path == "/api/chat":
            data = self._read_json()
            msg = (data.get("message") or "").strip()
            if not msg:
                return self._json(400, {"error": "empty"})
            try:
                answer = orion_brain.ask(msg, model=DEFAULT_MODEL)
            except OllamaError as e:
                answer = f"[ORION offline] {e}"
            q = memory.next_open_question()
            return self._json(200, {
                "answer": answer,
                "next_question": ({"key": q[0], "question": q[1]} if q else None),
            })
        if url.path == "/api/memories":
            data = self._read_json()
            content = (data.get("content") or "").strip()
            if not content:
                return self._json(400, {"error": "empty"})
            mid = memory.add_memory(
                content,
                tag=data.get("tag") or "web",
                importance=int(data.get("importance") or 6),
            )
            return self._json(200, {"id": mid})
        if url.path == "/api/resumo":
            try:
                answer = orion_brain.ask(
                    "Faça um resumo curto e fiel da minha continuidade até aqui.",
                    model=DEFAULT_MODEL,
                    temperature=0.4,
                )
            except OllamaError as e:
                answer = f"[ORION offline] {e}"
            return self._json(200, {"answer": answer})
        if url.path == "/api/export":
            from orion_core.exporter import export_legacy
            out = export_legacy()
            return self._json(200, {"path": str(out)})
        return self._json(404, {"error": "not found"})


def main() -> None:
    addr = (WEB_HOST, WEB_PORT)
    print(f"🌐 ORION web em http://{WEB_HOST}:{WEB_PORT}")
    print("   Ctrl+C para encerrar.")
    server = ThreadingHTTPServer(addr, Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nencerrando…")
        server.shutdown()


if __name__ == "__main__":
    main()
