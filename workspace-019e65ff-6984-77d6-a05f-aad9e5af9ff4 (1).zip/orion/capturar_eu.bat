@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py capturar_eu.py
) else (
  python capturar_eu.py
)
pause
endlocal
