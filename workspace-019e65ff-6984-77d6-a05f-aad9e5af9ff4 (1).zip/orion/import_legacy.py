"""
Importa diários, documentos e áudios para o legado.

Uso:  python import_legacy.py "/caminho/para/diarios"
"""
from __future__ import annotations
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from orion_core.importer import import_path


def main() -> None:
    if len(sys.argv) < 2:
        print('Uso: python import_legacy.py "/caminho/para/diarios"')
        sys.exit(2)
    path = sys.argv[1]
    stats = import_path(path)
    if "error" in stats:
        print("⚠️", stats["error"])
        sys.exit(1)
    print(
        f"📥 arquivos={stats['files']} memórias={stats['memories']} "
        f"áudios={stats['audios']} ignorados={stats['skipped']}"
    )
    for d in stats["details"]:
        print(" ", d)


if __name__ == "__main__":
    main()
