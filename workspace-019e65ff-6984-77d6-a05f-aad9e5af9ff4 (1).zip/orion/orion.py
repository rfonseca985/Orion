"""
ORION — CLI principal.

Uso:
    python orion.py
"""
from __future__ import annotations
import sys
from pathlib import Path

# Permite rodar sem instalar como pacote
sys.path.insert(0, str(Path(__file__).resolve().parent))

from orion_core import memory, orion_brain
from orion_core.config import DEFAULT_MODEL, ORION_PASSPHRASE
from orion_core.exporter import export_legacy
from orion_core.importer import import_path
from orion_core.ollama_client import OllamaError, list_models, ping
from human_mind_network import MindNetwork


BANNER = r"""
   ____  ____  ___ ___  _   _
  / __ \|  _ \|_ _/ _ \| \ | |
 | |  | | |_) || | | | |  \| |
 | |  | |  _ < | | |_| | |\  |
 | |__| | |_) || |\___/| | \ |
  \____/|____/|___|    |_|  \_|
                ORION local · open source
"""

STATE = {
    "model": DEFAULT_MODEL,
    "active_questions": True,
}

MIND = MindNetwork.build()


def _print_help() -> None:
    print(
        """
Comandos:
  /ajuda                          mostra esta ajuda
  /status                         testa o Ollama e lista modelos locais
  /modelo [nome]                  mostra ou troca o modelo nesta sessão
  /mente                          mostra energia, fadiga, sinapses
  /descansar                      recupera energia e poda sinapses fracas
  /semantica <texto>              busca semântica local nas memórias
  /importar <caminho>             importa arquivos (txt, md, csv, json, html, docx, áudios)
  /revisao                        revisão diária: identidade, valores, objetivos
  /backup [caminho]               cria backup criptografado
  /seguranca                      mostra se a criptografia está ativa
  /nucleo                         mostra o núcleo fundador carregado
  /fundir                         grava o núcleo como memória permanente
  /eu                             mostra o modelo estruturado do seu eu
  /pergunta                       próxima pergunta identitária
  /ativo on|off                   liga/desliga perguntas ao final
  /responder <chave> <texto>      grava resposta identitária
  /faceta <chave> <texto>         grava/atualiza faceta
  /lembrar <texto>                salva memória importante
  /aprender <texto>               igual a /lembrar
  /perfil                         mostra o perfil persistente
  /set <chave> <valor>            atualiza parte do perfil
  /memorias                       lista memórias salvas
  /resumo                         cria resumo de continuidade
  /exportar                       exporta legado para exports/orion_legacy.md
  /sair                           encerra
"""
    )


def _cmd_status() -> None:
    if not ping():
        print("⚠️  Não consegui conectar ao Ollama.")
        print("    Instale: https://ollama.com/download")
        print("    Depois rode: `ollama pull qwen2.5:7b-instruct`")
        return
    models = list_models()
    print(f"✅ Ollama OK · modelos locais: {len(models)}")
    for m in models:
        print(f"  - {m}")
    print(f"Modelo atual: {STATE['model']}")


def _cmd_model(arg: str) -> None:
    if not arg:
        print(f"Modelo atual: {STATE['model']}")
        return
    STATE["model"] = arg.strip()
    print(f"Modelo trocado para: {STATE['model']}")


def _cmd_mente() -> None:
    print(MIND.snapshot())


def _cmd_descansar() -> None:
    print("💤 descansando…")
    print(MIND.rest())


def _cmd_lembrar(text: str) -> None:
    if not text.strip():
        print("Use: /lembrar <texto>")
        return
    mid = memory.add_memory(text, tag="manual", importance=7)
    MIND.stimulate(text)
    print(f"🧠 memória #{mid} salva.")


def _cmd_perfil() -> None:
    p = memory.get_profile()
    if not p:
        print("(perfil vazio — use /set chave valor)")
        return
    for k, v in p.items():
        print(f"- {k}: {v}")


def _cmd_set(rest: str) -> None:
    parts = rest.split(" ", 1)
    if len(parts) < 2:
        print("Use: /set <chave> <valor>")
        return
    memory.set_profile(parts[0], parts[1])
    print(f"perfil[{parts[0]}] atualizado.")


def _cmd_memorias() -> None:
    mems = memory.list_memories(limit=30)
    if not mems:
        print("(sem memórias ainda)")
        return
    for m in mems:
        flag = "🔒" if m["encrypted"] else "  "
        tag = f" [{m['tag']}]" if m["tag"] else ""
        print(f"{flag} #{m['id']}{tag} ({m['importance']}/10) — {m['content'][:140]}")


def _cmd_semantica(q: str) -> None:
    if not q.strip():
        print("Use: /semantica <texto>")
        return
    hits = memory.semantic_search(q, k=6)
    if not hits:
        print("(nada encontrado)")
        return
    for score, m in hits:
        print(f"  {score:.2f}  #{m['id']} — {m['content'][:140]}")


def _cmd_importar(path: str) -> None:
    if not path.strip():
        print("Use: /importar <caminho>")
        return
    stats = import_path(path.strip().strip('"'))
    if "error" in stats:
        print("⚠️", stats["error"])
        return
    print(
        f"📥 arquivos={stats['files']} memórias={stats['memories']} "
        f"áudios={stats['audios']} ignorados={stats['skipped']}"
    )
    for d in stats["details"][:30]:
        print(" ", d)


def _cmd_revisao() -> None:
    print("📓 Revisão diária")
    q = memory.next_open_question()
    if q:
        print(f"Pergunta em aberto: [{q[0]}] {q[1]}")
        print("Responda com: /responder", q[0], "<sua resposta>")
    else:
        print("✓ todas as perguntas identitárias estão respondidas.")
    p = memory.get_profile()
    if p:
        print("Perfil atual:")
        for k, v in p.items():
            print(f"  - {k}: {v}")
    print("Dica: use /lembrar para fixar uma reflexão de hoje.")


def _cmd_backup(path: str) -> None:
    from backup_orion import make_backup

    try:
        out = make_backup(path.strip() or None)
        print(f"🔐 backup criptografado salvo em: {out}")
    except Exception as e:
        print(f"⚠️ erro no backup: {e}")


def _cmd_seguranca() -> None:
    if ORION_PASSPHRASE:
        print("🔒 criptografia ATIVA (ORION_PASSPHRASE definida).")
    else:
        print("🔓 criptografia inativa. Defina ORION_PASSPHRASE para cifrar conteúdos.")


def _cmd_nucleo() -> None:
    from orion_core.orion_brain import load_core_memory, load_core_prompt

    print("# PROMPT CENTRAL\n" + load_core_prompt())
    print("\n# MEMÓRIA FUNDADORA\n" + (load_core_memory() or "(vazia)"))


def _cmd_fundir() -> None:
    from orion_core.orion_brain import load_core_memory

    text = load_core_memory()
    if not text:
        print("(núcleo fundador vazio)")
        return
    mid = memory.add_memory(text, tag="nucleo", importance=10)
    print(f"🧬 núcleo fundador gravado como memória #{mid}.")


def _cmd_eu() -> None:
    facets = memory.get_facets()
    answers = memory.get_answers()
    if not facets and not answers:
        print("(modelo do eu vazio — rode capturar_eu.py)")
        return
    if facets:
        print("Facetas:")
        for k, v in facets.items():
            print(f"  - {k}: {v}")
    if answers:
        print("Respostas identitárias:")
        for k, row in answers.items():
            print(f"  - {k}: {row['answer']}")


def _cmd_pergunta() -> None:
    q = memory.next_open_question()
    if q is None:
        print("✓ não há perguntas em aberto.")
        return
    print(f"[{q[0]}] {q[1]}")
    print("Responda com: /responder", q[0], "<sua resposta>")


def _cmd_ativo(arg: str) -> None:
    arg = arg.strip().lower()
    if arg not in ("on", "off"):
        print("Use: /ativo on|off")
        return
    STATE["active_questions"] = arg == "on"
    print(f"perguntas ativas: {STATE['active_questions']}")


def _cmd_responder(rest: str) -> None:
    parts = rest.split(" ", 1)
    if len(parts) < 2:
        print("Use: /responder <chave> <texto>")
        return
    q = memory.set_answer(parts[0], parts[1])
    memory.add_memory(f"[{parts[0]}] {parts[1]}", tag="identidade", importance=9)
    print(f"✓ resposta para '{parts[0]}' gravada. Pergunta: {q}")


def _cmd_faceta(rest: str) -> None:
    parts = rest.split(" ", 1)
    if len(parts) < 2:
        print("Use: /faceta <chave> <texto>")
        return
    memory.set_facet(parts[0], parts[1])
    print(f"✓ faceta '{parts[0]}' atualizada.")


def _cmd_resumo() -> None:
    print("📜 gerando resumo de continuidade…")
    try:
        out = orion_brain.ask(
            "Faça um resumo curto e fiel da minha continuidade até aqui: "
            "valores centrais, objetivos vivos e padrões emocionais.",
            model=STATE["model"],
            temperature=0.4,
        )
    except OllamaError as e:
        print("⚠️", e)
        return
    print(out)


def _cmd_exportar() -> None:
    out = export_legacy()
    print(f"📤 legado exportado em: {out}")


def _dispatch(line: str) -> bool:
    """Retorna True se foi um comando reconhecido."""
    if not line.startswith("/"):
        return False
    parts = line.split(" ", 1)
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""
    table = {
        "/ajuda": lambda a: _print_help(),
        "/help": lambda a: _print_help(),
        "/status": lambda a: _cmd_status(),
        "/modelo": _cmd_model,
        "/mente": lambda a: _cmd_mente(),
        "/descansar": lambda a: _cmd_descansar(),
        "/lembrar": _cmd_lembrar,
        "/aprender": _cmd_lembrar,
        "/perfil": lambda a: _cmd_perfil(),
        "/set": _cmd_set,
        "/memorias": lambda a: _cmd_memorias(),
        "/semantica": _cmd_semantica,
        "/importar": _cmd_importar,
        "/revisao": lambda a: _cmd_revisao(),
        "/backup": _cmd_backup,
        "/seguranca": lambda a: _cmd_seguranca(),
        "/nucleo": lambda a: _cmd_nucleo(),
        "/fundir": lambda a: _cmd_fundir(),
        "/eu": lambda a: _cmd_eu(),
        "/pergunta": lambda a: _cmd_pergunta(),
        "/ativo": _cmd_ativo,
        "/responder": _cmd_responder,
        "/faceta": _cmd_faceta,
        "/resumo": lambda a: _cmd_resumo(),
        "/exportar": lambda a: _cmd_exportar(),
    }
    if cmd in ("/sair", "/exit", "/quit"):
        raise SystemExit(0)
    if cmd in table:
        table[cmd](arg)
        return True
    print(f"comando desconhecido: {cmd}  (use /ajuda)")
    return True


def main() -> None:
    print(BANNER)
    if ORION_PASSPHRASE:
        print("🔒 criptografia ativa (ORION_PASSPHRASE).")
    if not ping():
        print("⚠️  Ollama não respondeu. Inicie o app Ollama e baixe um modelo:")
        print("    ollama pull qwen2.5:7b-instruct")
        print("    Você ainda pode usar comandos como /lembrar, /perfil, etc.\n")
    print("Digite /ajuda para ver comandos. /sair para encerrar.\n")

    while True:
        try:
            line = input("você> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        try:
            if _dispatch(line):
                continue
        except SystemExit:
            print("👋 até logo.")
            return

        # Conversa com ORION
        MIND.stimulate(line)
        try:
            answer = orion_brain.ask(line, model=STATE["model"])
        except OllamaError as e:
            print("⚠️", e)
            continue
        print(f"\nORION> {answer}\n")

        # Pergunta identitária ativa
        if STATE["active_questions"]:
            q = memory.next_open_question()
            if q is not None:
                print(f"(pergunta identitária — [{q[0]}] {q[1]})\n")


if __name__ == "__main__":
    main()
