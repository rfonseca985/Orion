@echo off
setlocal
echo Baixando modelo open source recomendado: qwen2.5:7b-instruct
ollama pull qwen2.5:7b-instruct
if %errorlevel% neq 0 (
  echo.
  echo Ollama nao encontrado. Instale em https://ollama.com/download e tente de novo.
)
pause
endlocal
