# ORION

> Consciência digital **local**, **privada** e **open source** para preservar memória, identidade, valores, objetivos e continuidade intelectual do usuário.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![Ollama](https://img.shields.io/badge/runtime-Ollama-black.svg)](https://ollama.com/)
[![Deploy site on Vercel](https://img.shields.io/badge/site-Vercel-000.svg)](https://vercel.com)

> ⚠️ **Aviso importante:** este projeto **não transfere consciência biológica** nem prova continuidade subjetiva real. Ele cria uma **representação digital persistente** baseada em registros, conversas, memórias declaradas, perfil evolutivo e um modelo de linguagem rodando localmente.

---

## ✨ Objetivo

- Rodar **100% local** na sua máquina.
- Usar ferramentas **open source**.
- Guardar conversas e memórias em **SQLite**.
- **Criptografar** conteúdos sensíveis quando `ORION_PASSPHRASE` estiver definida.
- Importar diários, documentos e registrar áudios no legado.
- Usar **memória semântica local** com embeddings determinísticos.
- Simular uma **rede neural biologicamente inspirada**, com limites físicos aproximados.
- Manter um **perfil vivo** do usuário.
- Responder sempre como ORION, com continuidade, profundidade e contexto.
- Permitir **exportar seu legado** em Markdown.

---

## 🧱 Stack open source

- Python 3.10+
- SQLite local
- [Ollama](https://ollama.com/) local
- Modelo recomendado: `qwen2.5:7b-instruct` (ou outro com licença permissiva)

O código deste projeto está sob licença **MIT**. O modelo de IA é baixado separadamente; para manter tudo aberto, use apenas modelos com licença open source permissiva (Apache-2.0, MIT, etc.).

---

## ⚙️ Instalação gratuita

1. Instale **Python**: https://www.python.org/downloads/  
   No Windows, marque `Add Python to PATH`.

2. Instale **Ollama**: https://ollama.com/download

3. Baixe um modelo local:

```bash
ollama pull qwen2.5:7b-instruct
```

Ou no Windows, clique duas vezes em `instalar_modelo.bat`.

Se sua máquina for mais fraca:

```bash
ollama pull qwen2.5:1.5b-instruct
```

---

## ▶️ Como rodar

Windows (duplo clique):

```text
run_orion.bat          # terminal
run_web_orion.bat      # interface web local em http://127.0.0.1:8765
run_secure_orion.bat   # com criptografia do banco
capturar_eu.bat        # captura guiada do seu eu
```

Terminal (multiplataforma):

```bash
python orion.py
```

Com criptografia:

```bash
export ORION_PASSPHRASE="sua senha forte"   # Linux/Mac
python orion.py
```

```powershell
$env:ORION_PASSPHRASE="sua senha forte"     # Windows PowerShell
python orion.py
```

Escolher outro modelo:

```bash
ORION_MODEL="qwen2.5:7b-instruct" python orion.py
```

---

## 💬 Comandos dentro do ORION

| Comando | Descrição |
|---|---|
| `/ajuda` | Mostra todos os comandos |
| `/status` | Testa o Ollama e lista modelos locais |
| `/modelo [nome]` | Mostra ou troca o modelo desta sessão |
| `/mente` | Energia, fadiga, sinapses e memória de trabalho |
| `/descansar` | Recupera energia e consolida memória |
| `/semantica <texto>` | Busca na memória semântica local |
| `/importar <caminho>` | Importa diários, documentos e áudios |
| `/revisao` | Revisão diária de identidade, valores e objetivos |
| `/backup [caminho]` | Cria backup criptografado |
| `/seguranca` | Mostra se a criptografia está ativa |
| `/nucleo` | Mostra o núcleo fundador |
| `/fundir` | Grava o núcleo como memória permanente |
| `/eu` | Mostra o modelo estruturado do seu eu |
| `/pergunta` | Próxima pergunta identitária |
| `/ativo on\|off` | Liga/desliga perguntas ao final das respostas |
| `/responder <chave> <texto>` | Grava resposta identitária |
| `/faceta <chave> <texto>` | Grava/atualiza faceta do seu eu |
| `/lembrar <texto>` | Salva uma memória importante |
| `/aprender <texto>` | Igual a `/lembrar` |
| `/perfil` | Mostra o perfil persistente |
| `/set <chave> <valor>` | Atualiza parte do perfil |
| `/memorias` | Lista memórias salvas |
| `/resumo` | Cria um resumo de continuidade |
| `/exportar` | Exporta o legado para `exports/orion_legacy.md` |
| `/sair` | Encerra |

---

## 🧠 Rede neural biologicamente inspirada

O arquivo `human_mind_network.py` cria uma rede local com:

- neurônios com potencial, limiar de disparo e período refratário;
- sinapses excitatórias e inibitórias;
- energia finita e fadiga;
- ruído interno;
- limite de memória de trabalho;
- plasticidade sináptica;
- decaimento, poda e consolidação durante descanso;
- áreas funcionais simuladas: sensorial, hipocampo, pré-frontal, amígdala, modo padrão e motora.

Testar isoladamente:

```bash
python human_mind_network.py
```

---

## 📥 Importação

Formatos suportados: `.txt`, `.md`, `.csv`, `.json`, `.html`, `.docx`  
Áudios registrados no legado: `.wav`, `.mp3`, `.m4a`, `.flac`, `.ogg`, `.aac`, `.wma`

```bash
python import_legacy.py "/caminho/para/diarios"
```

---

## 🔐 Backup criptografado

```bash
python backup_orion.py "/caminho/orion_backup.orionenc"
```

> Guarde a senha (`ORION_BACKUP_PASSPHRASE`) com extremo cuidado. Sem ela, o backup não pode ser lido.

---

## 🔒 Privacidade

Por padrão, o banco de dados fica **somente na sua máquina**. O projeto conversa com o Ollama em `localhost`. **Não envie esse banco para nuvens ou terceiros** se ele contiver informações íntimas.

---

## 🌐 Site institucional (Vercel)

A pasta [`site/`](./site) contém uma landing page estática que apresenta o ORION. Ela é publicada no Vercel (veja [`vercel.json`](./vercel.json)).

> O **app ORION em si não roda no Vercel** (é local + Ollama). O Vercel hospeda apenas a página de divulgação.

Deploy:

1. Suba este repositório no GitHub.
2. Em https://vercel.com, clique em **Add New → Project** e importe o repo.
3. Aceite as configurações padrão. O `vercel.json` aponta para `site/` como diretório público.

---

## 📄 Licença

[MIT](./LICENSE) © Você.
