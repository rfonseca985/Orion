@echo off
setlocal
cd /d "%~dp0"
set /p ORION_PASSPHRASE=Senha (nao fica salva): 
where py >nul 2>nul
if %errorlevel%==0 (
  py orion.py
) else (
  python orion.py
)
set ORION_PASSPHRASE=
endlocal
