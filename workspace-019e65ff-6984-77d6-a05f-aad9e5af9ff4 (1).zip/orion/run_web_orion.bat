@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py web_orion.py
) else (
  python web_orion.py
)
endlocal
