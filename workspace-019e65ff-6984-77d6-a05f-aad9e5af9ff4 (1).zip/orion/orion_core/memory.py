"""Memórias, perfil, semântica e legado."""
from __future__ import annotations
import re
from typing import Iterable

from . import embeddings
from .config import ORION_PASSPHRASE
from .crypto import maybe_decrypt_text, maybe_encrypt_text
from .db import db, now


# ----------- PROFILE -----------
def set_profile(key: str, value: str) -> None:
    with db() as c:
        c.execute(
            "INSERT INTO profile(key,value,updated_at) VALUES(?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key.strip(), value.strip(), now()),
        )


def get_profile() -> dict[str, str]:
    with db() as c:
        rows = c.execute("SELECT key,value FROM profile ORDER BY key").fetchall()
    return {r["key"]: r["value"] for r in rows}


# ----------- MEMORIES -----------
def add_memory(content: str, tag: str | None = None, importance: int = 5) -> int:
    content = (content or "").strip()
    if not content:
        return 0
    stored, enc = maybe_encrypt_text(content, ORION_PASSPHRASE)
    with db() as c:
        cur = c.execute(
            "INSERT INTO memories(content,tag,importance,encrypted,created_at) VALUES(?,?,?,?,?)",
            (stored, tag, max(1, min(10, importance)), 1 if enc else 0, now()),
        )
        mem_id = cur.lastrowid
        # Index semântico sempre usa o texto em claro
        vec = embeddings.embed(content)
        c.execute(
            "INSERT OR REPLACE INTO semantic_index(memory_id,vector) VALUES(?,?)",
            (mem_id, embeddings.pack(vec)),
        )
    return mem_id


def list_memories(limit: int = 50) -> list[dict]:
    with db() as c:
        rows = c.execute(
            "SELECT id,content,tag,importance,encrypted,created_at FROM memories "
            "ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    out = []
    for r in rows:
        out.append(
            {
                "id": r["id"],
                "content": maybe_decrypt_text(r["content"], ORION_PASSPHRASE),
                "tag": r["tag"],
                "importance": r["importance"],
                "encrypted": bool(r["encrypted"]),
                "created_at": r["created_at"],
            }
        )
    return out


def semantic_search(query: str, k: int = 5) -> list[tuple[float, dict]]:
    q = embeddings.embed(query)
    with db() as c:
        rows = c.execute(
            "SELECT m.id,m.content,m.tag,m.importance,m.encrypted,m.created_at,s.vector "
            "FROM memories m JOIN semantic_index s ON s.memory_id = m.id"
        ).fetchall()
    scored = []
    for r in rows:
        vec = embeddings.unpack(r["vector"])
        score = embeddings.cosine(q, vec)
        scored.append(
            (
                score,
                {
                    "id": r["id"],
                    "content": maybe_decrypt_text(r["content"], ORION_PASSPHRASE),
                    "tag": r["tag"],
                    "importance": r["importance"],
                    "encrypted": bool(r["encrypted"]),
                    "created_at": r["created_at"],
                },
            )
        )
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:k]


# ----------- CONVERSATIONS -----------
def log_message(role: str, content: str) -> None:
    if not content:
        return
    stored, enc = maybe_encrypt_text(content, ORION_PASSPHRASE)
    with db() as c:
        c.execute(
            "INSERT INTO conversations(role,content,encrypted,created_at) VALUES(?,?,?,?)",
            (role, stored, 1 if enc else 0, now()),
        )


def recent_messages(limit: int = 12) -> list[dict]:
    with db() as c:
        rows = c.execute(
            "SELECT role,content,encrypted,created_at FROM conversations "
            "ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    out = []
    for r in reversed(rows):
        out.append(
            {
                "role": r["role"],
                "content": maybe_decrypt_text(r["content"], ORION_PASSPHRASE),
                "created_at": r["created_at"],
            }
        )
    return out


# ----------- IDENTITY -----------
IDENTITY_QUESTIONS: list[tuple[str, str]] = [
    ("essencia", "Qual é a sua essência mais profunda em uma frase?"),
    ("valores", "Quais valores você manteria mesmo sob pressão extrema?"),
    ("medos", "Quais são os medos que mais moldam suas decisões?"),
    ("desejos", "O que você mais deseja construir nos próximos 10 anos?"),
    ("legado", "O que você quer que sobreviva de você?"),
    ("contradicoes", "Quais contradições internas você reconhece em si mesmo?"),
    ("estilo_cognitivo", "Como você pensa? Que padrão sua mente segue?"),
    ("tom_orion", "Como ORION deve falar com você? Direto, profundo, leve?"),
    ("origem", "Que parte da sua história explica melhor quem você é hoje?"),
    ("decisoes_chave", "Quais decisões revelam seu verdadeiro caráter?"),
]


def set_facet(key: str, value: str) -> None:
    with db() as c:
        c.execute(
            "INSERT INTO identity_facets(key,value,updated_at) VALUES(?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key.strip(), value.strip(), now()),
        )


def get_facets() -> dict[str, str]:
    with db() as c:
        rows = c.execute("SELECT key,value FROM identity_facets ORDER BY key").fetchall()
    return {r["key"]: r["value"] for r in rows}


def set_answer(key: str, answer: str) -> str:
    question = dict(IDENTITY_QUESTIONS).get(key, key)
    with db() as c:
        c.execute(
            "INSERT INTO identity_answers(key,question,answer,updated_at) VALUES(?,?,?,?) "
            "ON CONFLICT(key) DO UPDATE SET answer=excluded.answer, updated_at=excluded.updated_at",
            (key, question, answer.strip(), now()),
        )
    return question


def get_answers() -> dict[str, dict]:
    with db() as c:
        rows = c.execute(
            "SELECT key,question,answer,updated_at FROM identity_answers ORDER BY key"
        ).fetchall()
    return {r["key"]: dict(r) for r in rows}


def next_open_question() -> tuple[str, str] | None:
    answered = set(get_answers().keys())
    for key, q in IDENTITY_QUESTIONS:
        if key not in answered:
            return key, q
    return None


_SIGNAL_PATTERNS = [
    (re.compile(r"\beu\s+quero\b", re.IGNORECASE), "desejo"),
    (re.compile(r"\beu\s+valorizo\b", re.IGNORECASE), "valor"),
    (re.compile(r"\bmeu\s+objetivo\b", re.IGNORECASE), "objetivo"),
    (re.compile(r"\btenho\s+medo\b", re.IGNORECASE), "medo"),
    (re.compile(r"\bnunca\s+aceitarei\b", re.IGNORECASE), "limite"),
    (re.compile(r"\bsou\s+", re.IGNORECASE), "identidade"),
]


def capture_signals(text: str) -> list[str]:
    kinds = []
    for pat, kind in _SIGNAL_PATTERNS:
        if pat.search(text or ""):
            with db() as c:
                c.execute(
                    "INSERT INTO identity_signals(kind,content,created_at) VALUES(?,?,?)",
                    (kind, text.strip(), now()),
                )
            kinds.append(kind)
    return kinds


def recent_signals(limit: int = 20) -> list[dict]:
    with db() as c:
        rows = c.execute(
            "SELECT kind,content,created_at FROM identity_signals "
            "ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(r) for r in rows]


# ----------- LEGACY -----------
def register_legacy(path: str, kind: str, size: int, note: str = "") -> int:
    with db() as c:
        cur = c.execute(
            "INSERT INTO legacy_files(path,kind,bytes,note,created_at) VALUES(?,?,?,?,?)",
            (path, kind, size, note, now()),
        )
        return cur.lastrowid


def list_legacy() -> list[dict]:
    with db() as c:
        rows = c.execute(
            "SELECT id,path,kind,bytes,note,created_at FROM legacy_files ORDER BY id DESC"
        ).fetchall()
    return [dict(r) for r in rows]


# ----------- META -----------
def meta_set(key: str, value: str) -> None:
    with db() as c:
        c.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )


def meta_get(key: str, default: str = "") -> str:
    with db() as c:
        row = c.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default
