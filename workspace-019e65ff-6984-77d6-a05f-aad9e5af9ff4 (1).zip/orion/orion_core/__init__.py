"""ORION core — biblioteca interna usada por orion.py, web_orion.py, etc."""
__version__ = "0.1.0"
