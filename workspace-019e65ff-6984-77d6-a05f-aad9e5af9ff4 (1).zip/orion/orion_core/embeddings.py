"""
Embeddings determinísticos locais por hashing vetorial.

Sem internet, sem API, sem dependências. Não rivaliza com modelos modernos,
mas é suficiente para buscas semânticas grosseiras dentro do próprio banco.
"""
from __future__ import annotations
import hashlib
import math
import re
import struct
from typing import Iterable

DIM = 256
_TOKEN_RE = re.compile(r"\w+", re.UNICODE)


def tokenize(text: str) -> list[str]:
    return [t.lower() for t in _TOKEN_RE.findall(text or "")]


def embed(text: str) -> list[float]:
    vec = [0.0] * DIM
    tokens = tokenize(text)
    if not tokens:
        return vec
    for tok in tokens:
        h = hashlib.sha256(tok.encode("utf-8")).digest()
        # cada token contribui em 4 posições (8 bytes consumidos)
        for i in range(4):
            idx = h[i * 2] | (h[i * 2 + 1] << 8)
            sign = 1.0 if (h[8 + i] & 1) else -1.0
            vec[idx % DIM] += sign
    # normalização L2
    norm = math.sqrt(sum(v * v for v in vec))
    if norm > 0:
        vec = [v / norm for v in vec]
    return vec


def pack(vec: list[float]) -> bytes:
    return struct.pack(f"{len(vec)}f", *vec)


def unpack(blob: bytes) -> list[float]:
    n = len(blob) // 4
    return list(struct.unpack(f"{n}f", blob))


def cosine(a: list[float], b: list[float]) -> float:
    if len(a) != len(b):
        return 0.0
    return sum(x * y for x, y in zip(a, b))
