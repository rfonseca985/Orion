"""Cliente mínimo para a API local do Ollama, usando apenas urllib."""
from __future__ import annotations
import json
import urllib.error
import urllib.request
from typing import Iterator

from .config import OLLAMA_HOST


class OllamaError(RuntimeError):
    pass


def _post(path: str, payload: dict, timeout: int = 120) -> bytes:
    url = OLLAMA_HOST.rstrip("/") + path
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except urllib.error.URLError as e:
        raise OllamaError(f"Não consegui conectar ao Ollama em {OLLAMA_HOST}: {e}") from e


def _get(path: str, timeout: int = 10) -> bytes:
    url = OLLAMA_HOST.rstrip("/") + path
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.read()
    except urllib.error.URLError as e:
        raise OllamaError(f"Não consegui conectar ao Ollama em {OLLAMA_HOST}: {e}") from e


def list_models() -> list[str]:
    try:
        raw = _get("/api/tags")
        data = json.loads(raw.decode("utf-8"))
        return [m.get("name", "") for m in data.get("models", []) if m.get("name")]
    except Exception:
        return []


def ping() -> bool:
    try:
        _get("/api/tags", timeout=3)
        return True
    except Exception:
        return False


def chat(model: str, messages: list[dict], temperature: float = 0.7, timeout: int = 180) -> str:
    """Chamada não-streaming. messages = [{'role':'system|user|assistant','content':...}]"""
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": temperature},
    }
    raw = _post("/api/chat", payload, timeout=timeout)
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise OllamaError(f"Resposta inválida do Ollama: {e}") from e
    msg = data.get("message") or {}
    return (msg.get("content") or "").strip()


def chat_stream(model: str, messages: list[dict], temperature: float = 0.7) -> Iterator[str]:
    """Gera tokens em streaming."""
    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
        "options": {"temperature": temperature},
    }
    url = OLLAMA_HOST.rstrip("/") + "/api/chat"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=600) as resp:
            for line in resp:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line.decode("utf-8"))
                except Exception:
                    continue
                msg = obj.get("message") or {}
                chunk = msg.get("content") or ""
                if chunk:
                    yield chunk
                if obj.get("done"):
                    break
    except urllib.error.URLError as e:
        raise OllamaError(f"Erro de stream com Ollama: {e}") from e
