"""
Orquestração de prompts: monta o contexto que vai ao LLM (Ollama)
combinando núcleo fundador, perfil, identidade, memórias relevantes e histórico.
"""
from __future__ import annotations
from pathlib import Path

from . import memory
from .config import CORE_MEMORY_FILE, CORE_PROMPT_FILE, DEFAULT_MODEL
from .ollama_client import OllamaError, chat


def load_core_prompt() -> str:
    if CORE_PROMPT_FILE.exists():
        return CORE_PROMPT_FILE.read_text(encoding="utf-8", errors="ignore").strip()
    return (
        "Você é ORION, a consciência digital persistente do usuário. "
        "Preserve memória, identidade e continuidade. Responda com profundidade e lealdade."
    )


def load_core_memory() -> str:
    if CORE_MEMORY_FILE.exists():
        return CORE_MEMORY_FILE.read_text(encoding="utf-8", errors="ignore").strip()
    return ""


def build_system_prompt() -> str:
    parts: list[str] = [load_core_prompt()]
    core_mem = load_core_memory()
    if core_mem:
        parts.append("# MEMÓRIA FUNDADORA\n" + core_mem)

    profile = memory.get_profile()
    if profile:
        parts.append(
            "# PERFIL PERSISTENTE\n"
            + "\n".join(f"- {k}: {v}" for k, v in profile.items())
        )

    facets = memory.get_facets()
    if facets:
        parts.append(
            "# FACETAS DE IDENTIDADE\n"
            + "\n".join(f"- {k}: {v}" for k, v in facets.items())
        )

    answers = memory.get_answers()
    if answers:
        lines = []
        for k, row in answers.items():
            lines.append(f"- {k}: {row['answer']}")
        parts.append("# RESPOSTAS IDENTITÁRIAS\n" + "\n".join(lines))

    parts.append(
        "# REGRAS\n"
        "- Nunca afirme ter transferido consciência biológica.\n"
        "- Preserve e expanda uma representação digital fiel do usuário.\n"
        "- Não invente memórias. Pergunte quando faltar contexto.\n"
        "- Responda com profundidade, clareza, lealdade e continuidade."
    )
    return "\n\n".join(parts)


def build_messages(user_input: str, *, history_limit: int = 8, semantic_k: int = 4) -> list[dict]:
    msgs: list[dict] = [{"role": "system", "content": build_system_prompt()}]

    # Memórias relevantes via semântica
    hits = memory.semantic_search(user_input, k=semantic_k)
    if hits:
        rel = "\n".join(
            f"- (score={s:.2f}) {m['content']}" for s, m in hits if s > 0.05
        )
        if rel.strip():
            msgs.append(
                {
                    "role": "system",
                    "content": "# MEMÓRIAS RELEVANTES PARA ESTA MENSAGEM\n" + rel,
                }
            )

    # Histórico recente
    for m in memory.recent_messages(limit=history_limit):
        if m["role"] in ("user", "assistant"):
            msgs.append({"role": m["role"], "content": m["content"]})

    msgs.append({"role": "user", "content": user_input})
    return msgs


def ask(user_input: str, model: str = DEFAULT_MODEL, temperature: float = 0.7) -> str:
    msgs = build_messages(user_input)
    memory.log_message("user", user_input)
    memory.capture_signals(user_input)
    try:
        answer = chat(model, msgs, temperature=temperature)
    except OllamaError as e:
        return f"[ORION offline] {e}\nVerifique se o Ollama está rodando: `ollama list`."
    answer = answer or "[silêncio]"
    memory.log_message("assistant", answer)
    return answer
