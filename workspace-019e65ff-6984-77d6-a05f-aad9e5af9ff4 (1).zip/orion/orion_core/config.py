"""Configurações globais do ORION (caminhos, modelo padrão, env vars)."""
from __future__ import annotations
import os
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT_DIR / "data"
EXPORTS_DIR = ROOT_DIR / "exports"
DB_PATH = DATA_DIR / "orion.sqlite3"

DATA_DIR.mkdir(parents=True, exist_ok=True)
EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_MODEL = os.environ.get("ORION_MODEL", "qwen2.5:7b-instruct")
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
ORION_PASSPHRASE = os.environ.get("ORION_PASSPHRASE", "").strip() or None
ORION_BACKUP_PASSPHRASE = os.environ.get("ORION_BACKUP_PASSPHRASE", "").strip() or None

WEB_HOST = os.environ.get("ORION_WEB_HOST", "127.0.0.1")
WEB_PORT = int(os.environ.get("ORION_WEB_PORT", "8765"))

CORE_PROMPT_FILE = ROOT_DIR / "prompt_orion_uma_linha.txt"
CORE_MEMORY_FILE = ROOT_DIR / "memoria_fundadora_orion.md"
