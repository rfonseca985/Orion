"""Exporta o legado do ORION em Markdown."""
from __future__ import annotations
import datetime as dt
from pathlib import Path

from . import memory
from .config import EXPORTS_DIR


def export_legacy(path: str | None = None) -> Path:
    out = Path(path) if path else (EXPORTS_DIR / "orion_legacy.md")
    out.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    lines.append("# Legado ORION")
    lines.append(f"_Exportado em {dt.datetime.now().isoformat(timespec='seconds')}_\n")

    profile = memory.get_profile()
    if profile:
        lines.append("## Perfil")
        for k, v in profile.items():
            lines.append(f"- **{k}**: {v}")
        lines.append("")

    facets = memory.get_facets()
    if facets:
        lines.append("## Facetas de identidade")
        for k, v in facets.items():
            lines.append(f"- **{k}**: {v}")
        lines.append("")

    answers = memory.get_answers()
    if answers:
        lines.append("## Respostas identitárias")
        for k, row in answers.items():
            lines.append(f"### {k}")
            lines.append(f"> {row['question']}")
            lines.append("")
            lines.append(row["answer"])
            lines.append("")

    mems = memory.list_memories(limit=10_000)
    if mems:
        lines.append("## Memórias")
        for m in mems:
            ts = dt.datetime.fromtimestamp(m["created_at"]).isoformat(timespec="seconds")
            tag = f" `{m['tag']}`" if m["tag"] else ""
            lines.append(f"- [{ts}]{tag} — {m['content']}")
        lines.append("")

    legacy = memory.list_legacy()
    if legacy:
        lines.append("## Arquivos de legado")
        for f in legacy:
            ts = dt.datetime.fromtimestamp(f["created_at"]).isoformat(timespec="seconds")
            lines.append(f"- [{ts}] ({f['kind']}, {f['bytes']} bytes) {f['path']}  \n  {f['note'] or ''}")
        lines.append("")

    out.write_text("\n".join(lines), encoding="utf-8")
    return out
