"""
Criptografia local do ORION usando APENAS biblioteca padrão.

Estratégia:
- Derivação de chave: PBKDF2-HMAC-SHA256 (200.000 iterações, salt aleatório de 16 bytes).
- Cifra: stream cipher construída sobre HMAC-SHA256 em modo contador (HKDF-Expand-like).
- Autenticação: HMAC-SHA256 sobre (header || nonce || ciphertext), chave independente.
- Formato: magic(8) || version(1) || salt(16) || nonce(16) || hmac(32) || ciphertext

Aviso: para projetos que precisam de AES/ChaCha de fato, instale `cryptography`.
Esta implementação é AEAD razoável apenas com stdlib e foi pensada para
proteger memórias locais contra leitura casual.
"""
from __future__ import annotations
import hashlib
import hmac
import os
import struct

MAGIC = b"ORIONv1\x00"
VERSION = 1
SALT_LEN = 16
NONCE_LEN = 16
MAC_LEN = 32
PBKDF2_ITERS = 200_000
HEADER_LEN = len(MAGIC) + 1 + SALT_LEN + NONCE_LEN + MAC_LEN


def _derive_keys(passphrase: str, salt: bytes) -> tuple[bytes, bytes]:
    """Deriva duas chaves de 32 bytes: (enc_key, mac_key)."""
    master = hashlib.pbkdf2_hmac(
        "sha256", passphrase.encode("utf-8"), salt, PBKDF2_ITERS, dklen=64
    )
    return master[:32], master[32:]


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    """Gera keystream via HMAC-SHA256 em modo contador."""
    out = bytearray()
    counter = 0
    while len(out) < length:
        block = hmac.new(key, nonce + struct.pack(">Q", counter), hashlib.sha256).digest()
        out.extend(block)
        counter += 1
    return bytes(out[:length])


def encrypt(plaintext: bytes, passphrase: str) -> bytes:
    salt = os.urandom(SALT_LEN)
    nonce = os.urandom(NONCE_LEN)
    enc_key, mac_key = _derive_keys(passphrase, salt)
    ks = _keystream(enc_key, nonce, len(plaintext))
    ciphertext = bytes(a ^ b for a, b in zip(plaintext, ks))
    header = MAGIC + bytes([VERSION]) + salt + nonce
    mac = hmac.new(mac_key, header + ciphertext, hashlib.sha256).digest()
    return MAGIC + bytes([VERSION]) + salt + nonce + mac + ciphertext


def decrypt(blob: bytes, passphrase: str) -> bytes:
    if len(blob) < HEADER_LEN:
        raise ValueError("Bloco cifrado pequeno demais.")
    if blob[: len(MAGIC)] != MAGIC:
        raise ValueError("Formato desconhecido (magic inválido).")
    version = blob[len(MAGIC)]
    if version != VERSION:
        raise ValueError(f"Versão {version} não suportada.")
    off = len(MAGIC) + 1
    salt = blob[off : off + SALT_LEN]; off += SALT_LEN
    nonce = blob[off : off + NONCE_LEN]; off += NONCE_LEN
    mac = blob[off : off + MAC_LEN]; off += MAC_LEN
    ciphertext = blob[off:]
    enc_key, mac_key = _derive_keys(passphrase, salt)
    header = MAGIC + bytes([VERSION]) + salt + nonce
    expected = hmac.new(mac_key, header + ciphertext, hashlib.sha256).digest()
    if not hmac.compare_digest(mac, expected):
        raise ValueError("HMAC inválido — senha errada ou arquivo corrompido.")
    ks = _keystream(enc_key, nonce, len(ciphertext))
    return bytes(a ^ b for a, b in zip(ciphertext, ks))


def maybe_encrypt_text(text: str, passphrase: str | None) -> tuple[str, bool]:
    """Retorna (conteúdo_armazenado, foi_cifrado)."""
    if not passphrase:
        return text, False
    blob = encrypt(text.encode("utf-8"), passphrase)
    import base64
    return "ENC1:" + base64.b64encode(blob).decode("ascii"), True


def maybe_decrypt_text(value: str, passphrase: str | None) -> str:
    if not value.startswith("ENC1:"):
        return value
    import base64
    blob = base64.b64decode(value[5:].encode("ascii"))
    if not passphrase:
        return "[conteúdo cifrado — defina ORION_PASSPHRASE para ler]"
    try:
        return decrypt(blob, passphrase).decode("utf-8")
    except Exception as e:
        return f"[erro ao decifrar: {e}]"
