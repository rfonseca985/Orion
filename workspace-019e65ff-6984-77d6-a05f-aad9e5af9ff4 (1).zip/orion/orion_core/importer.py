"""Importação de diários, documentos e áudios para o legado / memórias."""
from __future__ import annotations
import csv
import io
import json
import re
import zipfile
from html.parser import HTMLParser
from pathlib import Path

from . import memory

TEXT_EXTS = {".txt", ".md", ".log"}
CSV_EXTS = {".csv"}
JSON_EXTS = {".json"}
HTML_EXTS = {".html", ".htm"}
DOCX_EXTS = {".docx"}
AUDIO_EXTS = {".wav", ".mp3", ".m4a", ".flac", ".ogg", ".aac", ".wma"}


class _HTMLText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip += 1

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if not self._skip:
            self.parts.append(data)


def _read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="ignore")


def _read_csv(p: Path) -> str:
    out = io.StringIO()
    with p.open("r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            out.write(" | ".join(row) + "\n")
    return out.getvalue()


def _read_json(p: Path) -> str:
    try:
        data = json.loads(_read_text(p))
    except Exception:
        return _read_text(p)
    return json.dumps(data, ensure_ascii=False, indent=2)


def _read_html(p: Path) -> str:
    parser = _HTMLText()
    parser.feed(_read_text(p))
    text = "".join(parser.parts)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def _read_docx(p: Path) -> str:
    try:
        with zipfile.ZipFile(p) as z:
            with z.open("word/document.xml") as f:
                xml = f.read().decode("utf-8", errors="ignore")
    except Exception:
        return ""
    # Extrai conteúdo entre <w:t ...> ... </w:t>
    texts = re.findall(r"<w:t[^>]*>([^<]*)</w:t>", xml)
    return "\n".join(texts)


def extract_text(p: Path) -> str:
    ext = p.suffix.lower()
    if ext in TEXT_EXTS:
        return _read_text(p)
    if ext in CSV_EXTS:
        return _read_csv(p)
    if ext in JSON_EXTS:
        return _read_json(p)
    if ext in HTML_EXTS:
        return _read_html(p)
    if ext in DOCX_EXTS:
        return _read_docx(p)
    return ""


def _chunk(text: str, max_chars: int = 1200) -> list[str]:
    text = (text or "").strip()
    if not text:
        return []
    chunks: list[str] = []
    paragraphs = re.split(r"\n\s*\n", text)
    buf: list[str] = []
    size = 0
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if size + len(para) + 2 > max_chars and buf:
            chunks.append("\n\n".join(buf))
            buf, size = [], 0
        buf.append(para)
        size += len(para) + 2
    if buf:
        chunks.append("\n\n".join(buf))
    return chunks


def import_path(path: str) -> dict:
    p = Path(path).expanduser()
    if not p.exists():
        return {"error": f"caminho não existe: {p}"}
    files: list[Path] = []
    if p.is_file():
        files = [p]
    else:
        for f in p.rglob("*"):
            if f.is_file():
                files.append(f)
    stats = {"files": 0, "memories": 0, "audios": 0, "skipped": 0, "details": []}
    for f in files:
        ext = f.suffix.lower()
        try:
            if ext in AUDIO_EXTS:
                memory.register_legacy(str(f.resolve()), "audio", f.stat().st_size,
                                       note="aguardando transcrição offline")
                stats["audios"] += 1
                stats["files"] += 1
                stats["details"].append(f"🎵 {f.name}")
                continue
            text = extract_text(f)
            if not text.strip():
                stats["skipped"] += 1
                continue
            chunks = _chunk(text)
            for i, ch in enumerate(chunks):
                tag = f"import:{f.name}"
                memory.add_memory(f"[{f.name} #{i+1}/{len(chunks)}]\n{ch}", tag=tag, importance=4)
                stats["memories"] += 1
            memory.register_legacy(str(f.resolve()), "document", f.stat().st_size,
                                   note=f"{len(chunks)} chunk(s)")
            stats["files"] += 1
            stats["details"].append(f"📄 {f.name} ({len(chunks)} chunks)")
        except Exception as e:
            stats["skipped"] += 1
            stats["details"].append(f"⚠️ {f.name}: {e}")
    return stats
