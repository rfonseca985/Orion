# Política de Segurança

## Versões suportadas

A versão `main` recebe correções de segurança.

## Reportando vulnerabilidades

Se você descobrir uma vulnerabilidade que comprometa:

- a privacidade do banco local,
- a criptografia (`ORION_PASSPHRASE`, `ORION_BACKUP_PASSPHRASE`),
- ou a integridade dos backups `.orionenc`,

**não abra uma issue pública**. Contate o mantenedor de forma privada e aguarde resposta antes de divulgar.

## Boas práticas para usuários

- Use senhas fortes e únicas para `ORION_PASSPHRASE` e `ORION_BACKUP_PASSPHRASE`.
- Não commit o arquivo `.env`, nem a pasta `data/`, nem arquivos `*.orionenc`.
- Guarde backups em mídia offline.
- Não compartilhe `data/orion.sqlite3` com terceiros.
