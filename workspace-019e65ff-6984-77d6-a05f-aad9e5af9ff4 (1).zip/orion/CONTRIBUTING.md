# Contribuindo com o ORION

Obrigado por considerar contribuir! Algumas diretrizes:

## Princípios

- **Local primeiro.** Nada de dependências obrigatórias de nuvem.
- **Privacidade.** Nenhum dado do usuário deve sair da máquina sem ação explícita.
- **Open source.** Apenas bibliotecas e modelos com licença permissiva (MIT, Apache-2.0, BSD).
- **Continuidade.** Cada mudança deve preservar memória/identidade já registradas.

## Como contribuir

1. Faça um fork do repositório.
2. Crie uma branch: `git checkout -b feat/minha-mudanca`.
3. Faça commits pequenos e descritivos.
4. Abra um Pull Request descrevendo o **porquê** da mudança.

## Reportando problemas

- Use **Issues** com:
  - sistema operacional
  - versão do Python
  - modelo do Ollama usado
  - passos para reproduzir
  - logs (sem dados pessoais)

## Segurança

Se encontrar uma vulnerabilidade que afete privacidade ou criptografia, **não abra issue pública**. Envie por contato privado ao mantenedor.
