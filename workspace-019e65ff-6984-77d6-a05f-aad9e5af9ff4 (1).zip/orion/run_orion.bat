@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py orion.py
) else (
  where python >nul 2>nul
  if %errorlevel%==0 (
    python orion.py
  ) else (
    echo Python nao foi encontrado. Instale em https://www.python.org/downloads/ e marque "Add Python to PATH".
    pause
  )
)
endlocal
