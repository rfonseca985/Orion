"""
Captura guiada do "eu" — faz perguntas fundamentais e grava as respostas
como respostas identitárias e memórias prioritárias.

Uso:  python capturar_eu.py
"""
from __future__ import annotations
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from orion_core import memory


def main() -> None:
    print("📓 Captura do Eu — responda com calma. Pressione Enter vazio para pular.\n")
    answered = 0
    for key, question in memory.IDENTITY_QUESTIONS:
        existing = memory.get_answers().get(key)
        if existing:
            print(f"[{key}] já respondida: {existing['answer'][:80]}…")
            again = input("  sobrescrever? (s/N) ").strip().lower()
            if again != "s":
                continue
        try:
            ans = input(f"\n>> {question}\n   ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n(captura interrompida)")
            break
        if not ans:
            continue
        memory.set_answer(key, ans)
        memory.add_memory(f"[{key}] {ans}", tag="identidade", importance=9)
        answered += 1
        print("  ✓ gravada.")
    print(f"\nFim da captura. {answered} resposta(s) atualizada(s).")


if __name__ == "__main__":
    main()
