# Deploy — Git + Vercel

Guia rápido para publicar este projeto.

## 1) Publicar o código no GitHub

```bash
cd orion
git init
git add .
git commit -m "chore: bootstrap ORION (código + site)"

git branch -M main
git remote add origin https://github.com/SEU_USUARIO/orion.git
git push -u origin main
```

> O `.gitignore` já protege `data/`, `*.sqlite3`, `*.orionenc`, `.env` e caches.
> Nunca commit informações íntimas.

## 2) Publicar a landing page no Vercel

O **app ORION em si NÃO roda no Vercel** (precisa de Python + Ollama local).  
O que vai pro Vercel é apenas a **landing page estática** em `site/`.

### Opção A — via Dashboard (recomendado)

1. Acesse https://vercel.com → **Add New → Project**.
2. Importe o repositório `orion`.
3. Em **Framework Preset**, selecione **Other**.
4. Em **Build & Output Settings**:
   - Build Command: *(deixe vazio)*
   - Output Directory: `site`
5. Clique em **Deploy**.

O `vercel.json` na raiz já define `outputDirectory: "site"` e headers de segurança.

### Opção B — via CLI

```bash
npm i -g vercel
vercel login
vercel        # primeiro deploy (preview)
vercel --prod # produção
```

## 3) Domínio customizado (opcional)

No Vercel → Project → **Settings → Domains** → adicione seu domínio e configure o DNS conforme instruções.

## 4) Atualizando

Cada `git push` para `main` dispara um novo deploy automático no Vercel.
